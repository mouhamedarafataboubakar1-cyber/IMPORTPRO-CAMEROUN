import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Award,
  CheckCircle2,
  Building2,
  MapPin,
  ArrowRight,
  ShieldCheck,
  Lock,
  Phone,
  Camera,
  ArrowLeft,
  Users,
  DollarSign
} from 'lucide-react';

export const DevenirAmbassadeurPage: React.FC = () => {
  const { cities, applyForAmbassador, setCurrentSection, setUserRole } = useApp();

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [cityId, setCityId] = useState(cities[0]?.id || 'ngaoundere');
  const [neighborhood, setNeighborhood] = useState('');
  const [officeAddress, setOfficeAddress] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const selectedCity = cities.find((c) => c.id === cityId) || cities[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const result = applyForAmbassador({
      name,
      phone,
      whatsapp: whatsapp || phone,
      email,
      cityId,
      neighborhood,
      officeAddress,
      photoUrl: photoUrl || undefined,
      password
    });

    if (result.success) {
      setIsSubmitted(true);
    }
  };

  return (
    <div className="py-10 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Navigation back */}
        <div className="mb-6">
          <button
            onClick={() => setCurrentSection('accueil')}
            className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-2xs transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Retour à l'accueil</span>
          </button>
        </div>

        {isSubmitted ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center shadow-sm space-y-5">
            <div className="w-16 h-16 bg-emerald-100 text-[#007A3D] rounded-2xl flex items-center justify-center mx-auto shadow-sm">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div className="space-y-2 max-w-lg mx-auto">
              <div className="inline-flex items-center gap-1.5 bg-amber-50 text-amber-800 text-xs font-extrabold px-3 py-1 rounded-full border border-amber-200">
                Statut : En attente de validation
              </div>
              <h2 className="text-2xl font-extrabold text-slate-900">
                Candidature Transmise avec Succès !
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Merci <strong>{name}</strong>. Votre dossier pour représenter la ville de <strong>{selectedCity.name}</strong> (Quartier <em>{neighborhood}</em>) a été transmis à la direction générale ImportPro.
              </p>
            </div>

            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 max-w-md mx-auto text-left text-xs space-y-2 text-slate-700">
              <div className="font-bold text-slate-900 pb-1 border-b border-slate-200">
                Prochaines étapes de validation :
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-[#007A3D]">•</span>
                <span>Examen et vérification de l'adresse de votre bureau ou point local par l'administrateur.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-[#007A3D]">•</span>
                <span>Attribution de votre identifiant unique et de votre code officiel (ex: <strong>IMPORTPRO-{selectedCity.code}-00X</strong>).</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-[#007A3D]">•</span>
                <span>Activation de votre tableau de bord personnel pour percevoir vos commissions de <strong>2 000 FCFA par personne validée</strong>.</span>
              </div>
            </div>

            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => {
                  setUserRole('admin');
                  setCurrentSection('dashboard-admin');
                }}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow-sm transition-colors cursor-pointer"
              >
                Aller dans l'Admin pour valider cette candidature (Démo)
              </button>
              <button
                onClick={() => setCurrentSection('accueil')}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors"
              >
                Retourner sur le site
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            
            {/* Header banner */}
            <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white p-6 sm:p-10">
              <div className="inline-flex items-center gap-2 bg-[#FCD116] text-slate-950 font-bold px-3 py-1 rounded-full text-xs uppercase tracking-wider mb-3">
                <Award className="w-3.5 h-3.5" />
                <span>Réseau Officiel ImportPro Cameroun</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
                Devenir Ambassadeur Officiel
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-2xl leading-relaxed">
                Chaque ville peut avoir son ambassadeur officiel avec un bureau ou point local certifié. Remplissez ce formulaire d'inscription. Après validation par l'administrateur, votre compte sera automatiquement créé avec votre code et lien de parrainage exclusif.
              </p>

              <div className="mt-4 inline-flex items-center gap-2 bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 px-3.5 py-1.5 rounded-xl text-xs font-bold">
                <span>Commission officielle :</span>
                <span className="text-[#FCD116]">2 000 FCFA par personne validée</span>
              </div>
            </div>

            {/* Application Form */}
            <form onSubmit={handleSubmit} className="p-6 sm:p-10 space-y-6">
              
              {/* Section 1: Identité */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  01. Identité & Coordonnées du Candidat
                </h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Nom complet */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Nom complet * :
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Nom et prénom complet"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Adresse Email * :
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="adresse.email@domaine.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                    />
                  </div>

                  {/* Numéro de téléphone */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Numéro de téléphone * :
                    </label>
                    <div className="relative">
                      <input
                        type="tel"
                        required
                        placeholder="+237 6XX XX XX XX"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                      />
                    </div>
                  </div>

                  {/* WhatsApp */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Numéro WhatsApp (recommandé pour les notifications) * :
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+237 6XX XX XX XX"
                      value={whatsapp}
                      onChange={(e) => setWhatsapp(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Localisation & Bureau */}
              <div className="pt-4 border-t border-slate-100">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  02. Ville & Emplacement du Bureau ou Point Local
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Ville */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Ville représentée (Une seule ville officielle) * :
                    </label>
                    <select
                      value={cityId}
                      onChange={(e) => setCityId(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                    >
                      {cities.map((city) => (
                        <option key={city.id} value={city.id}>
                          {city.name} ({city.region}) — Code : {city.code}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Quartier */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Quartier * :
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Votre quartier ou secteur"
                      value={neighborhood}
                      onChange={(e) => setNeighborhood(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                    />
                  </div>

                  {/* Adresse du bureau ou point local */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Adresse précise du bureau ou point local d'accueil * :
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Adresse précise de votre local d'accueil ou bureau"
                      value={officeAddress}
                      onChange={(e) => setOfficeAddress(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                    />
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      Ce lieu physique sera publié sur la page de votre ville pour accueillir les participants.
                    </span>
                  </div>
                </div>
              </div>

              {/* Section 3: Photo & Sécurité */}
              <div className="pt-4 border-t border-slate-100">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  03. Photo de Profil & Sécurité du Compte
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Photo */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Photo ou avatar professionnel (URL ou descriptif) :
                    </label>
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400 shrink-0">
                        <Camera className="w-5 h-5" />
                      </div>
                      <input
                        type="text"
                        placeholder="Ex : https://... ou laissez vide pour avatar auto"
                        value={photoUrl}
                        onChange={(e) => setPhotoUrl(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                      />
                    </div>
                  </div>

                  {/* Mot de passe */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Mot de passe personnel * :
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        required
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                      />
                    </div>
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      Ce mot de passe vous permettra de vous connecter à votre tableau de bord.
                    </span>
                  </div>
                </div>
              </div>

              {/* Terms & submit */}
              <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-xs text-slate-500 leading-snug">
                  En soumettant ce formulaire, vous acceptez les conditions du programme ambassadeur (commission de 2 000 FCFA par inscription validée).
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto px-8 py-3.5 bg-[#007A3D] hover:bg-emerald-800 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
                >
                  <span>Soumettre ma candidature ambassadeur</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </form>

          </div>
        )}

      </div>
    </div>
  );
};
