import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Award, CheckCircle2, Building2, MapPin, Lock, Camera } from 'lucide-react';

export const BecomeAmbassadorModal: React.FC = () => {
  const {
    isAmbassadorModalOpen,
    closeAmbassadorModal,
    cities,
    applyForAmbassador
  } = useApp();

  const [name, setName] = useState('');
  const [cityId, setCityId] = useState(cities[0]?.id || 'ngaoundere');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [officeAddress, setOfficeAddress] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [password, setPassword] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isAmbassadorModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = applyForAmbassador({
      name,
      phone,
      whatsapp: whatsapp || phone,
      email,
      cityId,
      neighborhood,
      officeAddress,
      photoUrl: photoUrl || undefined,
      password
    });

    if (result.success) {
      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        closeAmbassadorModal();
      }, 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 my-8 relative">
        
        {/* Close Button */}
        <button
          onClick={closeAmbassadorModal}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
          aria-label="Fermer"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-14 h-14 bg-emerald-100 text-[#007A3D] rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-extrabold text-slate-900">
              Candidature Transmise !
            </h3>
            <p className="text-xs text-slate-600 max-w-xs mx-auto">
              Votre dossier a été enregistré avec le statut <strong>« En attente de validation »</strong> par l'administrateur. Votre code officiel vous sera attribué dès approbation.
            </p>
          </div>
        ) : (
          <>
            <div className="mb-5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-[#007A3D] mb-1 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-[#FCD116]" />
                <span>Réseau Officiel ImportPro Cameroun</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                Devenir Ambassadeur Officiel
              </h2>
              <div className="mt-2 bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 text-xs text-[#007A3D] font-extrabold">
                « Commission ambassadeur : 2 000 FCFA par personne validée »
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Nom complet * :
                </label>
                <input
                  type="text"
                  required
                  placeholder="Nom et prénom complet"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Téléphone * :
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+237 6XX XX XX XX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    WhatsApp * :
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+237 6XX XX XX XX"
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Email * :
                </label>
                <input
                  type="email"
                  required
                  placeholder="adresse.email@domaine.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Ville * :
                  </label>
                  <select
                    value={cityId}
                    onChange={(e) => setCityId(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-bold text-slate-900 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    {cities.map((city) => (
                      <option key={city.id} value={city.id}>
                        {city.name} ({city.code})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Quartier * :
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Votre quartier"
                    value={neighborhood}
                    onChange={(e) => setNeighborhood(e.target.value)}
                    className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Adresse du bureau ou point local d'accueil * :
                </label>
                <input
                  type="text"
                  required
                  placeholder="Adresse de votre local ou bureau"
                  value={officeAddress}
                  onChange={(e) => setOfficeAddress(e.target.value)}
                  className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Mot de passe personnel pour votre espace * :
                </label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeAmbassadorModal}
                  className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold rounded-xl shadow-2xs transition-colors cursor-pointer"
                >
                  Envoyer ma candidature
                </button>
              </div>

            </form>
          </>
        )}

      </div>
    </div>
  );
};

