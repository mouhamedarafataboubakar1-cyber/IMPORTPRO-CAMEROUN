import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  MapPin,
  Calendar,
  Clock,
  UserCheck,
  Phone,
  ArrowRight,
  ShieldCheck,
  Building2,
  Users
} from 'lucide-react';

export const VillesSection: React.FC = () => {
  const { cities, openRegistrationModal } = useApp();
  const [selectedRegionFilter, setSelectedRegionFilter] = useState<string>('all');

  const filteredCities = selectedRegionFilter === 'all'
    ? cities
    : cities.filter((c) => c.region.toLowerCase().includes(selectedRegionFilter.toLowerCase()));

  return (
    <section id="villes" className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-[#007A3D] mb-2 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#CE1126]" />
              <span>Tournée Présentielle du Fondateur</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Nos villes
            </h2>
            <p className="mt-2 text-sm text-slate-600 max-w-2xl">
              Retrouvez la formation physique et le bureau officiel ImportPro dans les 7 villes de la tournée :
            </p>
            {/* Clear 7 cities list */}
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {['Ngaoundéré', 'Maroua', 'Bertoua', 'Garoua-Boulaï', 'Pitoa', 'Guider', 'Figuil'].map((vName) => (
                <span
                  key={vName}
                  className="px-3 py-1 bg-white border border-slate-200 text-xs font-extrabold text-slate-900 rounded-lg shadow-2xs flex items-center gap-1"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-[#007A3D]" />
                  <span>{vName}</span>
                </span>
              ))}
            </div>
          </div>

          {/* Region Filter Buttons */}
          <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-slate-200 shadow-sm self-start md:self-auto overflow-x-auto max-w-full">
            <button
              onClick={() => setSelectedRegionFilter('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                selectedRegionFilter === 'all'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Toutes les 7 villes
            </button>
            <button
              onClick={() => setSelectedRegionFilter('Nord')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                selectedRegionFilter === 'Nord'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Nord (Guider, Pitoa, Figuil)
            </button>
            <button
              onClick={() => setSelectedRegionFilter('Extrême-Nord')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                selectedRegionFilter === 'Extrême-Nord'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Extrême-Nord (Maroua)
            </button>
            <button
              onClick={() => setSelectedRegionFilter('Adamaoua')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                selectedRegionFilter === 'Adamaoua'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Adamaoua (Ngaoundéré)
            </button>
            <button
              onClick={() => setSelectedRegionFilter('Est')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                selectedRegionFilter === 'Est'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Est (Bertoua, Garoua-Boulaï)
            </button>
          </div>
        </div>

        {/* Cities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCities.map((city) => {
            const isFillingFast = city.status === 'filling_fast';
            return (
              <div
                key={city.id}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* City Top Header */}
                  <div className="p-5 pb-3 border-b border-slate-100 bg-slate-50/50">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                        Région {city.region}
                      </span>
                      {isFillingFast ? (
                        <span className="text-[11px] font-bold text-[#CE1126] bg-red-50 border border-red-200 px-2 py-0.5 rounded-full">
                          Plus que {city.availableSeats} places
                        </span>
                      ) : (
                        <span className="text-[11px] font-bold text-[#007A3D] bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                          Inscriptions ouvertes
                        </span>
                      )}
                    </div>
                    <h3 className="text-xl font-extrabold text-slate-900 group-hover:text-[#007A3D] transition-colors">
                      {city.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 leading-snug">
                      {city.description}
                    </p>
                  </div>

                  {/* City Logistics Info */}
                  <div className="p-5 space-y-3.5 text-xs text-slate-700">
                    
                    {/* Session Date */}
                    <div className="flex items-start gap-2.5">
                      <Calendar className="w-4 h-4 text-[#007A3D] shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-slate-900 block">
                          Date : {city.nextSessionDate}
                        </span>
                        <span className="text-slate-500">{city.nextSessionTime}</span>
                      </div>
                    </div>

                    {/* Venue */}
                    <div className="flex items-start gap-2.5">
                      <Building2 className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-slate-900 block">Lieu de la formation :</span>
                        <span className={city.venueName === 'À renseigner' ? 'text-slate-400 italic' : 'text-slate-600'}>
                          {city.venueName || 'À renseigner'}
                        </span>
                      </div>
                    </div>

                    {/* Local Office */}
                    <div className="flex items-start gap-2.5">
                      <MapPin className="w-4 h-4 text-[#CE1126] shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-slate-900 block">Bureau / Point local :</span>
                        <span className={city.officeAddress === 'À renseigner' ? 'text-slate-400 italic' : 'text-slate-600'}>
                          {city.officeAddress || 'À renseigner'}
                        </span>
                      </div>
                    </div>

                    {/* Ambassador */}
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center font-bold text-xs">
                          {city.ambassadorName && city.ambassadorName !== 'À renseigner' ? city.ambassadorName.charAt(0) : <UserCheck className="w-3.5 h-3.5 text-slate-400" />}
                        </div>
                        <div>
                          <div className="text-[11px] text-slate-400">Ambassadeur officiel</div>
                          <div className={`font-bold ${city.ambassadorName === 'À renseigner' ? 'text-slate-500 italic' : 'text-slate-900'}`}>
                            {city.ambassadorName || 'À renseigner'}
                          </div>
                        </div>
                      </div>
                      {city.ambassadorPhone && city.ambassadorPhone !== 'À renseigner' ? (
                        <a
                          href={`tel:${city.ambassadorPhone}`}
                          className="text-slate-500 hover:text-[#007A3D] p-1.5 bg-slate-100 hover:bg-emerald-50 rounded-lg transition-colors"
                          title="Appeler l'ambassadeur"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </a>
                      ) : (
                        <span className="text-[10px] text-slate-400 italic bg-slate-100 px-2 py-0.5 rounded">
                          À renseigner
                        </span>
                      )}
                    </div>

                  </div>
                </div>

                {/* City Footer Action */}
                <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-3">
                  <div className="text-[11px] text-slate-500">
                    Tarif : <span className="font-bold text-slate-900">35 000 FCFA</span>
                  </div>
                  <button
                    onClick={() => openRegistrationModal(city.id)}
                    className="px-3.5 py-2 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                  >
                    <span>S'inscrire à {city.name}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Information Callout */}
        <div className="mt-12 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-amber-600" />
            </div>
            <div className="text-xs text-slate-600">
              <span className="font-bold text-slate-900 block text-sm">
                Votre ville ne figure pas encore dans le calendrier ?
              </span>
              Nous ouvrons de nouvelles sessions dès qu'un groupe de 20 entrepreneurs est réuni et qu'un ambassadeur local est certifié.
            </div>
          </div>
          <button
            onClick={() => openRegistrationModal()}
            className="px-4 py-2 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
          >
            Suggérer une ville ou groupe
          </button>
        </div>

      </div>
    </section>
  );
};
