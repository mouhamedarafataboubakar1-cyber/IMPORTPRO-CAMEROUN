import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS_IMAGE } from '../data/initialData';
import {
  Package,
  TrendingUp,
  Calculator,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  DollarSign,
  Layers
} from 'lucide-react';

export const ProduitsSection: React.FC = () => {
  const { products, openRegistrationModal } = useApp();
  const [selectedProduct, setSelectedProduct] = useState(products[0]);
  const [quantity, setQuantity] = useState<number>(20);
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const filteredProducts = categoryFilter === 'all'
    ? products
    : products.filter((p) => p.category === categoryFilter);

  // Profit calculation for selected product and quantity
  const totalCost = selectedProduct.costTotalFCFA * quantity;
  const totalRevenue = selectedProduct.retailPriceCameroonFCFA * quantity;
  const netProfit = totalRevenue - totalCost;

  return (
    <section id="produits" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-[#007A3D] mb-2 flex items-center gap-1.5">
              <Package className="w-4 h-4 text-[#FCD116]" />
              <span>Opportunités de Revente à Forte Marge</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Catalogue des Produits d'Importation Rentables
            </h2>
            <p className="mt-2 text-sm text-slate-600 max-w-2xl">
              Exemples réels de produits achetés à prix d'usine en Chine (1688 / Yiwu) et revendus à fort profit à Ngaoundéré, Maroua, Bertoua et partout au Cameroun.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200 self-start md:self-auto overflow-x-auto max-w-full">
            <button
              onClick={() => setCategoryFilter('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                categoryFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tous
            </button>
            <button
              onClick={() => setCategoryFilter('High-Tech')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                categoryFilter === 'High-Tech'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              High-Tech
            </button>
            <button
              onClick={() => setCategoryFilter('Solaire & Énergie')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                categoryFilter === 'Solaire & Énergie'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Solaire & Énergie
            </button>
            <button
              onClick={() => setCategoryFilter('Mode & Bagagerie')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                categoryFilter === 'Mode & Bagagerie'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mode & Sacs
            </button>
            <button
              onClick={() => setCategoryFilter('Maison & Électro')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                categoryFilter === 'Maison & Électro'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Maison & Électro
            </button>
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {filteredProducts.map((prod) => (
            <div
              key={prod.id}
              className={`rounded-2xl border transition-all p-5 flex flex-col justify-between cursor-pointer ${
                selectedProduct.id === prod.id
                  ? 'border-2 border-[#007A3D] bg-emerald-50/20 shadow-md ring-1 ring-emerald-500/20'
                  : 'border-slate-200 bg-white hover:border-slate-300 shadow-sm'
              }`}
              onClick={() => setSelectedProduct(prod)}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    {prod.category}
                  </span>
                  <span className="text-[11px] font-bold text-[#007A3D] bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                    +{prod.marginPercent}% de marge
                  </span>
                </div>

                <h3 className="font-extrabold text-slate-900 text-base mb-1">
                  {prod.name}
                </h3>
                <p className="text-xs text-slate-500 mb-4 line-clamp-2">
                  {prod.trendingReason}
                </p>

                {/* Price Breakdown in FCFA */}
                <div className="space-y-2 bg-slate-50 rounded-xl p-3.5 border border-slate-100 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Achat usine Chine :</span>
                    <strong className="text-slate-900">{(prod.chinaPriceFCFA ?? 0).toLocaleString()} FCFA ({prod.chinaPriceRMB} ¥)</strong>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Fret & douane estimé :</span>
                    <span>+{(prod.transportEstimateFCFA ?? 0).toLocaleString()} FCFA</span>
                  </div>
                  <div className="flex justify-between text-slate-800 font-bold pt-1 border-t border-slate-200">
                    <span>Coût total de revient :</span>
                    <span className="text-slate-900">{(prod.costTotalFCFA ?? 0).toLocaleString()} FCFA</span>
                  </div>
                  <div className="flex justify-between text-slate-800 font-bold">
                    <span>Prix de revente Cameroun :</span>
                    <span className="text-slate-900">{(prod.retailPriceCameroonFCFA ?? 0).toLocaleString()} FCFA</span>
                  </div>
                  <div className="flex justify-between text-[#007A3D] font-extrabold pt-1 border-t border-slate-200">
                    <span>Bénéfice net / unité :</span>
                    <span className="tabular-nums">+{(prod.marginFCFA ?? 0).toLocaleString()} FCFA</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Plateforme : <strong>{prod.sourcingPlatform}</strong>
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedProduct(prod);
                  }}
                  className="text-xs font-bold text-[#007A3D] hover:underline"
                >
                  Simuler la rentabilité →
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Interactive Margin Calculator for Selected Product */}
        <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-6 space-y-4">
              <div className="inline-flex items-center gap-2 bg-[#FCD116] text-slate-950 px-3 py-1 rounded-full text-xs font-extrabold uppercase">
                <Calculator className="w-3.5 h-3.5" />
                <span>Simulateur de Rentabilité Réelle</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-extrabold text-white">
                Calculateur d'importation : {selectedProduct.name}
              </h3>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Ajustez le volume de pièces à importer pour visualiser le capital initial requis et le bénéfice net total généré après revente sur le marché camerounais.
              </p>

              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-2">
                  <span>Quantité de pièces commandées :</span>
                  <span className="font-extrabold text-[#FCD116] text-base tabular-nums">{quantity} unités</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="100"
                  step="5"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full accent-[#FCD116] cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                  <span>5 unités (Débutant)</span>
                  <span>50 unités (Grossiste)</span>
                  <span>100 unités (Réseau)</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => openRegistrationModal()}
                  className="px-5 py-3 bg-[#007A3D] hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-colors flex items-center gap-2"
                >
                  <span>Apprendre à sourcer ce produit en atelier</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Financial Result Card */}
            <div className="lg:col-span-6 bg-slate-800/90 rounded-2xl p-6 border border-slate-700 space-y-4">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Bilan financier prévisionnel
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-700/60">
                  <span className="text-[11px] text-slate-400 block">Capital initial requis :</span>
                  <span className="text-lg sm:text-xl font-extrabold text-white tabular-nums">
                    {(totalCost ?? 0).toLocaleString()} FCFA
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">Produits + Fret + Douane</span>
                </div>

                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-700/60">
                  <span className="text-[11px] text-slate-400 block">Chiffre d'affaires revente :</span>
                  <span className="text-lg sm:text-xl font-extrabold text-white tabular-nums">
                    {(totalRevenue ?? 0).toLocaleString()} FCFA
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5">Vente locale Cameroun</span>
                </div>
              </div>

              <div className="bg-emerald-950/80 border border-emerald-500/40 p-4 rounded-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs text-emerald-300 font-bold block uppercase tracking-wide">
                      Bénéfice Net dans votre poche :
                    </span>
                    <span className="text-2xl sm:text-3xl font-extrabold text-[#FCD116] tabular-nums">
                      +{(netProfit ?? 0).toLocaleString()} FCFA
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-emerald-300 block font-semibold">Taux de profit :</span>
                    <span className="text-lg font-bold text-white">+{selectedProduct.marginPercent}%</span>
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-slate-400">
                Fournisseur vérifié sur <strong>{selectedProduct.sourcingPlatform}</strong>. Fiche technique et contact direct WeChat transmis aux participants de la formation physique.
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
