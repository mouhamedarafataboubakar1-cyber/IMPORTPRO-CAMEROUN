import React from 'react';
import { useApp } from '../context/AppContext';
import { HERO_IMAGE } from '../data/initialData';
import { ArrowRight, MapPin, Users, Award, ShieldCheck, CheckCircle2 } from 'lucide-react';

export const Hero: React.FC = () => {
  const { openRegistrationModal, openAmbassadorModal, setCurrentSection } = useApp();

  return (
    <section className="relative overflow-hidden bg-white border-b border-slate-200">
      {/* Background subtle grid pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px] opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16 lg:pt-16 lg:pb-20 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Value Proposition & Slogan */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* National trust lead-in */}
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#007A3D]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#007A3D]" />
              <span>IMPORTPRO CAMEROUN · « Apprendre. Importer. Revendre. »</span>
            </div>

            {/* Main Requested Message */}
            <h1 className="text-3xl sm:text-5xl lg:text-5xl font-extrabold tracking-tight text-slate-900 leading-[1.15]">
              « Apprenez à importer depuis la Chine et à développer votre activité de revente au Cameroun. »
            </h1>

            {/* Short Company Presentation */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              <strong>IMPORTPRO CAMEROUN</strong> organise des formations <strong>100% physiques et pratiques</strong> animées en personne par le fondateur dans votre ville. Découvrez les méthodes directes pour commander sur 1688 et Alibaba, acheminer vos colis en toute sécurité au Cameroun, et maximiser vos profits de revente.
            </p>

            {/* Key Value Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-sm text-slate-700">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#007A3D] shrink-0 mt-0.5" />
                <span><strong>Formation physique :</strong> Donnée en présentiel par le fondateur dans chaque ville.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#007A3D] shrink-0 mt-0.5" />
                <span><strong>Nos 7 villes :</strong> Bureaux officiels et points locaux permanents.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#007A3D] shrink-0 mt-0.5" />
                <span><strong>Sourcing direct :</strong> Fournisseurs fiables & transitaires vérifiés fournis.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#CE1126] shrink-0 mt-0.5" />
                <span><strong>Commission ambassadeur :</strong> 2 000 FCFA par personne validée.</span>
              </div>
            </div>

            {/* Primary Action Buttons requested by user */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-4">
              <button
                onClick={() => openRegistrationModal()}
                className="px-6 py-3.5 text-sm font-bold text-white bg-[#007A3D] hover:bg-emerald-800 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 group whitespace-nowrap"
              >
                <span>Réserver ma formation</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => setCurrentSection('devenir-ambassadeur')}
                className="px-6 py-3.5 text-sm font-bold text-slate-800 bg-white hover:bg-slate-50 border-2 border-slate-300 hover:border-slate-400 rounded-xl transition-colors flex items-center justify-center gap-2 whitespace-nowrap shadow-sm cursor-pointer"
              >
                <Users className="w-4 h-4 text-[#007A3D]" />
                <span>Devenir ambassadeur</span>
              </button>
            </div>

            {/* Regional Quick Links to 7 Cities */}
            <div className="pt-4 border-t border-slate-100">
              <div className="text-xs text-slate-500 font-medium mb-2 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#CE1126]" />
                <span>Villes actuellement programmées :</span>
              </div>
              <div className="flex flex-wrap gap-2 text-xs font-semibold text-slate-700">
                {['Ngaoundéré', 'Maroua', 'Bertoua', 'Garoua-Boulaï', 'Pitoa', 'Guider', 'Figuil'].map((cityName) => (
                  <button
                    key={cityName}
                    onClick={() => {
                      setCurrentSection('villes');
                      const elem = document.getElementById('villes');
                      if (elem) elem.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-[#007A3D] rounded border border-slate-200 hover:border-emerald-200 transition-colors"
                  >
                    {cityName}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Visual Feature Card & Image */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-slate-200 bg-slate-900 group">
              <img
                src={HERO_IMAGE}
                alt="Importation Chine Cameroun Fret et Logistique Maritime"
                referrerPolicy="no-referrer"
                className="w-full h-[380px] sm:h-[440px] object-cover object-center group-hover:scale-105 transition-transform duration-500"
                onError={(e) => {
                  // Fallback container styling
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />

              {/* Scrim Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-900/40 to-transparent" />

              {/* Badge on Image */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                <div className="bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-bold text-slate-900 flex items-center gap-2 shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-[#007A3D]" />
                  <span>Chine ➔ Cameroun direct</span>
                </div>
                <div className="bg-[#CE1126] text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm">
                  100% Présentiel
                </div>
              </div>

              {/* Bottom Card Content */}
              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-4 rounded-xl border border-white/40 shadow-lg space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
                  <span>Prochaine étape de la tournée</span>
                  <span className="text-[#007A3D] font-bold">Ngaoundéré & Maroua</span>
                </div>
                <div className="text-sm font-bold text-slate-900 leading-snug">
                  Atelier pratique en direct : simulation de commande sur 1688 & négociation fournisseur
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs text-slate-600">
                  <span>Frais d'inscription : 35 000 FCFA</span>
                  <span className="text-[#CE1126] font-semibold">Places limitées par ville</span>
                </div>
              </div>

            </div>

            {/* Floating Trust Indicator */}
            <div className="mt-4 bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#007A3D] text-white flex items-center justify-center shrink-0">
                <Award className="w-5 h-5 text-[#FCD116]" />
              </div>
              <div className="text-xs text-slate-700">
                <strong className="text-slate-900 block font-semibold">
                  Accompagnement post-formation garanti
                </strong>
                Intégration immédiate dans notre réseau fermé de groupage maritime vers le Cameroun.
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
