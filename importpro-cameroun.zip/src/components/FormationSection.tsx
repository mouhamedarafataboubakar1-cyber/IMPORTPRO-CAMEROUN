import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { WORKSHOP_IMAGE } from '../data/initialData';
import {
  CheckCircle2,
  BookOpen,
  Search,
  Users,
  ShoppingCart,
  Truck,
  Calculator,
  PackageCheck,
  TrendingUp,
  Share2,
  Calendar,
  Sparkles,
  ArrowRight
} from 'lucide-react';

export const FormationSection: React.FC = () => {
  const { openRegistrationModal, ceoInfo } = useApp();
  const [activeTab, setActiveTab] = useState<number>(0);

  const modules = [
    {
      id: 1,
      title: "Formation pratique sur l'importation Chine",
      icon: BookOpen,
      duration: "Matinée · Jour 1",
      highlight: "Comprendre l'écosystème commercial chinois et le circuit logistique vers l'Afrique.",
      details: [
        "Histoire et fonctionnement du marché chinois (Guangzhou, Yiwu, Shenzhen, Foshan)",
        "Différences concrètes entre 1688 (marché intérieur chinois), Taobao et Alibaba (export)",
        "Éviter les 5 erreurs fatales des débutants qui entraînent des blocages ou pertes de fonds",
        "Création et sécurisation de ses comptes d'acheteur avec vérification d'identité"
      ]
    },
    {
      id: 2,
      title: "Recherche de produits gagnants",
      icon: Search,
      duration: "Après-midi · Jour 1",
      highlight: "Dénicher des produits à forte valeur perçue et rotation rapide au Cameroun.",
      details: [
        "Méthode d'analyse des tendances sur les marchés camerounais (Grand Nord, Est, Littoral)",
        "Critères d'un produit gagnant : ratio poids/volume, fragilité, saisonnalité, marge brute",
        "Utilisation de la recherche par image et des mots-clés chinois traduits avec précision",
        "Analyse de la concurrence locale à Ngaoundéré, Maroua, Bertoua et Douala"
      ]
    },
    {
      id: 3,
      title: "Recherche de fournisseurs fiables",
      icon: Users,
      duration: "Matinée · Jour 2",
      highlight: "Identifier les vrais fabricants directs et contourner les courtiers non fiables.",
      details: [
        "Audit de réputation d'une usine sur 1688 (taux de retour, ancienneté, médailles d'or)",
        "Négociation directe via l'application Aliwangwang et WeChat avec modèles de phrases prêts à l'emploi",
        "Négociation des quantités minimales de commande (MOQ) adaptées à un petit budget",
        "Demande d'échantillons ou de vidéos en direct avant validation de production"
      ]
    },
    {
      id: 4,
      title: "Commande & Paiement sécurisé",
      icon: ShoppingCart,
      duration: "Après-midi · Jour 2",
      highlight: "Payer sans carte bancaire internationale et sans risque de blocage.",
      details: [
        "Procédure pas à pas pour passer commande sur 1688 en direct lors de la formation",
        "Les solutions de paiement en Yuan (RMB) fiables et acceptées depuis le Cameroun",
        "Protection des transactions et gestion des litiges ou remboursements automatisés",
        "Vérification de l'adresse de livraison de l'entrepôt du transitaire à Guangzhou/Yiwu"
      ]
    },
    {
      id: 5,
      title: "Transport Chine → Cameroun",
      icon: Truck,
      duration: "Matinée · Jour 3",
      highlight: "Maîtriser le fret maritime et aérien jusqu'à votre ville de résidence.",
      details: [
        "Fret aérien express (7-12 jours) vs groupage maritime au CBM (35-45 jours)",
        "Réseau exclusif de transitaires partenaires fiables avec entrepôts à Yiwu et Guangzhou",
        "Dédouanement complet et gestion des formalités douanières à l'arrivée au Cameroun",
        "Acheminement secondaire depuis Douala vers Ngaoundéré, Maroua, Bertoua, etc."
      ]
    },
    {
      id: 6,
      title: "Calcul des coûts & Rentabilité",
      icon: Calculator,
      duration: "Après-midi · Jour 3",
      highlight: "Calculer son prix de revient unitaire précis au franc CFA près.",
      details: [
        "Fiche de calcul Excel & Mobile remise à chaque participant en début d'atelier",
        "Intégration du taux de change FCFA/RMB, fret au kilo/volume, emballage et transport local",
        "Détermination du prix de vente optimal pour maximiser à la fois volume et marge nette",
        "Simulation d'une commande réelle sur 3 produits sélectionnés par la salle"
      ]
    },
    {
      id: 7,
      title: "Réception & Contrôle des marchandises",
      icon: PackageCheck,
      duration: "Matinée · Jour 4",
      highlight: "Réceptionner vos colis sans casse et procéder aux contrôles d'usage.",
      details: [
        "Procédure de déballage, pesée et vérification du colis devant le transitaire local",
        "Gestion des éventuels avaries, colis manquants et déclenchement des assurances",
        "Stockage sécurisé et gestion des stocks pour petits espaces"
      ]
    },
    {
      id: 8,
      title: "Techniques de revente au Cameroun",
      icon: TrendingUp,
      duration: "Après-midi · Jour 4",
      highlight: "Écouler son stock rapidement sans brader ses prix.",
      details: [
        "Packaging valorisant, création d'offres irrésistibles (packs duo, livraison offerte)",
        "Approche des boutiques locales pour du dépôt-vente ou de la vente en gros",
        "Gestion de la relation client, encaissement Orange Money & MTN Mobile Money"
      ]
    },
    {
      id: 9,
      title: "Marketing sur WhatsApp, TikTok et Facebook",
      icon: Share2,
      duration: "Journée Clôture · Jour 5",
      highlight: "Générer un flux continu de clients locaux sur les réseaux sociaux.",
      details: [
        "WhatsApp Business : Configuration catalogue pro, statuts à fort taux de conversion",
        "TikTok Cameroun : Scripts de vidéos simples pour présenter vos produits sans montrer son visage",
        "Facebook Ads local : Créer une publicité ciblée par ville (ex: Ngaoundéré ou Maroua) avec un petit budget (2 000 FCFA/jour)",
        "Closing commercial par message vocal et automatisation des réponses"
      ]
    }
  ];

  return (
    <section id="formation" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Lead-in */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-[#007A3D] mb-2 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#007A3D]" />
            <span>En Présentiel Direct · Pas de cours en ligne</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Formation 100% physique
          </h2>
          <p className="mt-3 text-base text-slate-700 leading-relaxed font-medium">
            La formation est <strong>100% PHYSIQUE</strong> et donnée <strong>en présentiel par le fondateur en personne dans chaque ville</strong>.
          </p>
          <p className="mt-2 text-sm text-slate-600 leading-relaxed">
            Il ne s'agit <strong>en aucun cas d'une formation en ligne ou d'un simple webinaire</strong>. Vous venez physiquement dans la salle de conférence avec votre smartphone ou votre ordinateur portable. Nous manipulons en direct les applications chinoises (1688, Taobao, WeChat), contactons les fournisseurs et calculons les coûts réels ensemble.
          </p>
        </div>

        {/* Highlight Banner with Workshop Image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-900 text-white rounded-3xl p-6 sm:p-8 mb-16 overflow-hidden relative shadow-lg">
          <div className="lg:col-span-7 space-y-4 relative z-10">
            <div className="inline-flex items-center gap-2 bg-[#007A3D] text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
              <span>Formation Physique & Pratique</span>
            </div>
            <h3 className="text-xl sm:text-3xl font-extrabold leading-tight text-white">
              « Le fondateur vient en personne dans votre ville pour vous former. »
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Chaque session regroupe un nombre limité de participants pour garantir un suivi personnalisé. À la fin de la formation, vous aurez déjà sélectionné vos produits, identifié vos fournisseurs chinois, et configuré votre canal de transport jusqu'à votre bureau local.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs">
              <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                <span className="block text-slate-400">Format :</span>
                <span className="font-bold text-white">Atelier présentiel en salle</span>
              </div>
              <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
                <span className="block text-slate-400">Intervenant :</span>
                <span className="font-bold text-[#FCD116]">{ceoInfo.title} : {ceoInfo.name}</span>
              </div>
              <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 col-span-2 sm:col-span-1">
                <span className="block text-slate-400">Bonus inclus :</span>
                <span className="font-bold text-white">Répertoire usines & transitaires</span>
              </div>
            </div>
            <div className="pt-2">
              <button
                onClick={() => openRegistrationModal()}
                className="px-5 py-3 text-xs sm:text-sm font-bold bg-[#007A3D] hover:bg-emerald-600 text-white rounded-xl shadow-md transition-colors inline-flex items-center gap-2"
              >
                <span>S'inscrire à la prochaine session de ma ville</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 relative z-10">
            <div className="rounded-2xl overflow-hidden border-2 border-slate-700 shadow-2xl relative group">
              <img
                src={WORKSHOP_IMAGE}
                alt="Formation physique Importation Chine Cameroun"
                referrerPolicy="no-referrer"
                className="w-full h-[280px] sm:h-[340px] object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
              <div className="absolute bottom-3 left-3 right-3 text-center bg-black/60 backdrop-blur-md py-1.5 px-3 rounded-lg text-[11px] font-medium text-slate-200">
                Atelier interactif en direct avec cas concrets d'importation
              </div>
            </div>
          </div>
        </div>

        {/* Modules Navigation / Interactive Explorer */}
        <div className="mb-6">
          <h3 className="text-xl font-bold text-slate-900 mb-2">
            Les 9 Piliers de la Formation
          </h3>
          <p className="text-xs sm:text-sm text-slate-600">
            Cliquez sur un module pour découvrir les compétences pratiques acquises au cours de l'atelier physique.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Modules List / Tabs */}
          <div className="lg:col-span-5 space-y-2">
            {modules.map((m, idx) => {
              const Icon = m.icon;
              const isActive = activeTab === idx;
              return (
                <button
                  key={m.id}
                  onClick={() => setActiveTab(idx)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between ${
                    isActive
                      ? 'bg-emerald-50 border-[#007A3D] text-[#007A3D] shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        isActive
                          ? 'bg-[#007A3D] text-white'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold leading-tight">
                        {m.title}
                      </div>
                      <div className="text-[11px] text-slate-400 font-medium">
                        Module 0{m.id} · {m.duration}
                      </div>
                    </div>
                  </div>
                  <span className={`text-xs font-semibold ${isActive ? 'text-[#007A3D]' : 'text-slate-300'}`}>
                    →
                  </span>
                </button>
              );
            })}
          </div>

          {/* Active Module Detail Card */}
          <div className="lg:col-span-7 bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8">
            <div className="flex items-center justify-between mb-4 pb-4 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded bg-[#007A3D] text-white text-[10px] font-bold uppercase tracking-wider">
                  Module 0{modules[activeTab].id}
                </span>
                <span className="text-xs text-slate-500 font-medium">
                  {modules[activeTab].duration}
                </span>
              </div>
              <span className="text-xs font-bold text-[#CE1126]">
                En présentiel avec le fondateur
              </span>
            </div>

            <h4 className="text-xl font-extrabold text-slate-900 mb-3">
              {modules[activeTab].title}
            </h4>

            <p className="text-sm font-medium text-slate-700 mb-6 bg-white p-3.5 rounded-xl border border-slate-200">
              « {modules[activeTab].highlight} »
            </p>

            <div className="space-y-3 mb-8">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Compétences pratiques transmises :
              </div>
              {modules[activeTab].details.map((detail, dIdx) => (
                <div key={dIdx} className="flex items-start gap-3 text-xs sm:text-sm text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>{detail}</span>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-slate-500">
                Supports fournis : Guide PDF, fiches usines & contacts WeChat
              </div>
              <button
                onClick={() => openRegistrationModal()}
                className="w-full sm:w-auto px-5 py-2.5 bg-[#007A3D] hover:bg-emerald-800 text-white text-xs font-bold rounded-lg shadow-sm transition-colors whitespace-nowrap text-center"
              >
                Participer à cet atelier
              </button>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
