import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Shield,
  Users,
  CheckCircle2,
  Clock,
  DollarSign,
  Building2,
  MapPin,
  Calendar,
  AlertCircle,
  Search,
  Check,
  X,
  CreditCard,
  Edit2,
  Save,
  RotateCcw,
  ArrowLeft,
  UserCheck,
  UserX,
  Phone,
  UserPlus,
  Mail,
  Lock,
  ExternalLink,
  Trash2
} from 'lucide-react';
import { Ambassador } from '../types';

export const AdminDashboard: React.FC = () => {
  const {
    cities,
    ambassadors,
    registrations,
    withdrawals,
    ceoInfo,
    updateCeoInfo,
    validateRegistration,
    cancelRegistration,
    processWithdrawal,
    approveAmbassador,
    rejectAmbassador,
    updateAmbassador,
    addAmbassador,
    removeAmbassadorFromCity,
    updateCity,
    resetDemoData,
    setCurrentSection,
    setCurrentAmbassadorId,
    setUserRole
  } = useApp();

  const [activeTab, setActiveTab] = useState<'inscriptions' | 'ambassadeurs' | 'candidatures' | 'retraits' | 'villes' | 'direction'>('inscriptions');
  const [cityFilter, setCityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Editing city state
  const [editingCityId, setEditingCityId] = useState<string | null>(null);
  const [editedDate, setEditedDate] = useState<string>('');
  const [editedVenue, setEditedVenue] = useState<string>('');
  const [editedOffice, setEditedOffice] = useState<string>('');
  const [editedNeighborhood, setEditedNeighborhood] = useState<string>('');
  const [editedAmbName, setEditedAmbName] = useState<string>('');
  const [editedAmbPhone, setEditedAmbPhone] = useState<string>('');

  // Editing ambassador modal state
  const [editingAmbassador, setEditingAmbassador] = useState<Ambassador | null>(null);

  // Adding ambassador modal state
  const [isAddingAmbassador, setIsAddingAmbassador] = useState<boolean>(false);
  const [newAmbName, setNewAmbName] = useState('');
  const [newAmbPhone, setNewAmbPhone] = useState('');
  const [newAmbWhatsapp, setNewAmbWhatsapp] = useState('');
  const [newAmbEmail, setNewAmbEmail] = useState('');
  const [newAmbCityId, setNewAmbCityId] = useState(cities[0]?.id || 'ngaoundere');
  const [newAmbNeighborhood, setNewAmbNeighborhood] = useState('');
  const [newAmbOffice, setNewAmbOffice] = useState('');
  const [newAmbCode, setNewAmbCode] = useState('');
  const [newAmbPassword, setNewAmbPassword] = useState('');

  // CEO Contact details state
  const [ceoPhone, setCeoPhone] = useState(ceoInfo.phone === 'À renseigner' ? '' : ceoInfo.phone);
  const [ceoWhatsapp, setCeoWhatsapp] = useState(ceoInfo.whatsapp === 'À renseigner' ? '' : ceoInfo.whatsapp);
  const [ceoEmail, setCeoEmail] = useState(ceoInfo.email === 'À renseigner' ? '' : ceoInfo.email);
  const [ceoOffice, setCeoOffice] = useState(ceoInfo.officeAddress === 'À renseigner' ? '' : ceoInfo.officeAddress);
  const [ceoCity, setCeoCity] = useState(ceoInfo.city === 'À renseigner' ? '' : ceoInfo.city);

  // Computations
  const totalRegistrations = registrations.length;
  const validatedRegistrations = registrations.filter((r) => r.status === 'validee').length;
  const pendingRegistrations = registrations.filter((r) => r.status === 'en_attente').length;
  const totalRevenue = validatedRegistrations * 35000;
  
  const activeAmbassadors = ambassadors.filter((a) => a.status === 'actif');
  const pendingAmbassadors = ambassadors.filter((a) => a.status === 'en_attente');
  
  const totalCommissionsPaidOrAvailable = activeAmbassadors.reduce(
    (acc, a) => acc + (a.totalCommissions ?? (a as any).commissionEarned ?? ((a.validatedCount ?? 0) * 2000)),
    0
  );
  const pendingWithdrawalsCount = withdrawals.filter((w) => w.status === 'en_attente').length;

  const filteredRegistrations = registrations.filter((r) => {
    const matchesCity = cityFilter === 'all' || r.cityId === cityFilter;
    const matchesStatus = statusFilter === 'all' || r.status === statusFilter;
    const matchesSearch =
      searchTerm === '' ||
      r.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.phone.includes(searchTerm) ||
      (r.referralCode && r.referralCode.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCity && matchesStatus && matchesSearch;
  });

  const handleStartEditCity = (city: (typeof cities)[0]) => {
    setEditingCityId(city.id);
    setEditedDate(city.nextSessionDate);
    setEditedVenue(city.venueName);
    setEditedOffice(city.officeAddress);
    setEditedNeighborhood(city.neighborhood);
    setEditedAmbName(city.ambassadorName);
    setEditedAmbPhone(city.ambassadorPhone);
  };

  const handleSaveEditCity = (cityId: string) => {
    updateCity(cityId, {
      nextSessionDate: editedDate,
      venueName: editedVenue.trim() || 'À renseigner',
      officeAddress: editedOffice.trim() || 'À renseigner',
      neighborhood: editedNeighborhood.trim() || 'À renseigner',
      ambassadorName: editedAmbName.trim() || 'À renseigner',
      ambassadorPhone: editedAmbPhone.trim() || 'À renseigner'
    });
    setEditingCityId(null);
  };

  const handleSaveAmbassadorEdits = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAmbassador) return;

    updateAmbassador(editingAmbassador.id, {
      name: editingAmbassador.name,
      phone: editingAmbassador.phone,
      whatsapp: editingAmbassador.whatsapp,
      email: editingAmbassador.email,
      neighborhood: editingAmbassador.neighborhood,
      officeAddress: editingAmbassador.officeAddress,
      cityId: editingAmbassador.cityId,
      cityName: cities.find((c) => c.id === editingAmbassador.cityId)?.name || editingAmbassador.cityName
    });

    setEditingAmbassador(null);
  };

  const handleCreateAmbassadorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAmbName.trim() || !newAmbPhone.trim()) return;

    addAmbassador({
      name: newAmbName.trim(),
      phone: newAmbPhone.trim(),
      whatsapp: newAmbWhatsapp.trim() || newAmbPhone.trim(),
      email: newAmbEmail.trim() || 'À renseigner',
      cityId: newAmbCityId,
      neighborhood: newAmbNeighborhood.trim() || 'À renseigner',
      officeAddress: newAmbOffice.trim() || 'À renseigner',
      referralCode: newAmbCode.trim() || undefined,
      password: newAmbPassword.trim() || undefined
    });

    // Reset and close
    setNewAmbName('');
    setNewAmbPhone('');
    setNewAmbWhatsapp('');
    setNewAmbEmail('');
    setNewAmbNeighborhood('');
    setNewAmbOffice('');
    setNewAmbCode('');
    setNewAmbPassword('');
    setIsAddingAmbassador(false);
  };

  const handleSaveCeoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateCeoInfo({
      phone: ceoPhone.trim() || 'À renseigner',
      whatsapp: ceoWhatsapp.trim() || 'À renseigner',
      email: ceoEmail.trim() || 'À renseigner',
      officeAddress: ceoOffice.trim() || 'À renseigner',
      city: ceoCity.trim() || 'À renseigner'
    });
  };

  return (
    <div className="py-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentSection('accueil')}
              className="p-2 bg-white rounded-lg border border-slate-200 text-slate-600 hover:text-slate-900 transition-colors shadow-2xs cursor-pointer"
              title="Retour à l'accueil"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <div className="text-xs font-bold text-[#CE1126] uppercase tracking-wider flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" />
                <span>Panneau de Contrôle Central — Accès Administrateur Global</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Administration — IMPORTPRO CAMEROUN
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={resetDemoData}
              className="px-3.5 py-2 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl flex items-center gap-1.5 shadow-2xs cursor-pointer"
              title="Remettre toutes les coordonnées à « À renseigner »"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
              <span>Purger données d'exemples</span>
            </button>
          </div>
        </div>

        {/* Global Key Performance Indicators */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="text-xs font-semibold text-slate-500">Inscriptions Totales</div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1 tabular-nums">
              {totalRegistrations}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {validatedRegistrations} validées · {pendingRegistrations} en attente
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="text-xs font-semibold text-slate-500">Ambassadeurs Actifs</div>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#007A3D] mt-1 tabular-nums">
              {activeAmbassadors.length}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {pendingAmbassadors.length} candidature(s) en attente
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="text-xs font-semibold text-slate-500">Chiffre d'Affaires Formations</div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1 tabular-nums">
              {(totalRevenue ?? 0).toLocaleString()} <span className="text-sm font-semibold text-slate-500">FCFA</span>
            </div>
            <div className="text-[11px] text-[#007A3D] font-semibold mt-1">
              35 000 FCFA / participant validé
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="text-xs font-semibold text-slate-500">Commissions Dues / Versées</div>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#007A3D] mt-1 tabular-nums">
              {(totalCommissionsPaidOrAvailable ?? 0).toLocaleString()} <span className="text-sm font-semibold text-slate-500">FCFA</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {pendingWithdrawalsCount} demande(s) de retrait en attente
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 border-b border-slate-200 overflow-x-auto bg-white p-1 rounded-t-2xl shadow-2xs">
          <button
            onClick={() => setActiveTab('inscriptions')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer ${
              activeTab === 'inscriptions'
                ? 'border-[#007A3D] text-[#007A3D]'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Inscriptions Participants ({registrations.length})</span>
            {pendingRegistrations > 0 && (
              <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                {pendingRegistrations}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('ambassadeurs')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer ${
              activeTab === 'ambassadeurs'
                ? 'border-[#007A3D] text-[#007A3D]'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Ambassadeurs Officiels ({activeAmbassadors.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('candidatures')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer relative ${
              activeTab === 'candidatures'
                ? 'border-[#007A3D] text-[#007A3D]'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Candidatures Reçues ({pendingAmbassadors.length})</span>
            {pendingAmbassadors.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-[#CE1126]" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('retraits')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer relative ${
              activeTab === 'retraits'
                ? 'border-[#007A3D] text-[#007A3D]'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Demandes de Retrait ({withdrawals.length})</span>
            {pendingWithdrawalsCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-[#CE1126]" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('villes')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer ${
              activeTab === 'villes'
                ? 'border-[#007A3D] text-[#007A3D]'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Les 7 Villes & Sessions ({cities.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('direction')}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 cursor-pointer ${
              activeTab === 'direction'
                ? 'border-[#007A3D] text-[#007A3D]'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Shield className="w-4 h-4 text-[#FCD116]" />
            <span>Direction (PDG : Mouhamed Arafat Aboubakar)</span>
          </button>
        </div>

        {/* Tab 1: Inscriptions & Validation des Commissions */}
        {activeTab === 'inscriptions' && (
          <div className="bg-white rounded-b-2xl border border-slate-200 p-6 shadow-2xs space-y-4">
            
            <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
              <div className="flex items-center gap-2 flex-1 max-w-md bg-slate-50 border border-slate-200 rounded-xl px-3 py-2">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Rechercher candidat, téléphone, code..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="bg-transparent text-xs text-slate-900 w-full focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <select
                  value={cityFilter}
                  onChange={(e) => setCityFilter(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-700 font-bold"
                >
                  <option value="all">Toutes les villes</option>
                  {cities.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-700 font-bold"
                >
                  <option value="all">Tous les statuts</option>
                  <option value="en_attente">En attente (Non validée)</option>
                  <option value="validee">Validée (Commission créditée)</option>
                  <option value="annulee">Annulée</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-3">Candidat</th>
                    <th className="py-3 px-3">Ville</th>
                    <th className="py-3 px-3">Ambassadeur / Code</th>
                    <th className="py-3 px-3">Règlement</th>
                    <th className="py-3 px-3">Statut Commission</th>
                    <th className="py-3 px-3 text-right">Action Admin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredRegistrations.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400">
                        Aucune inscription enregistrée pour le moment.
                      </td>
                    </tr>
                  ) : (
                    filteredRegistrations.map((reg) => (
                      <tr key={reg.id} className="hover:bg-slate-50/70">
                        <td className="py-3.5 px-3">
                          <div className="font-bold text-slate-900">{reg.fullName}</div>
                          <div className="text-[11px] text-slate-500">{reg.phone} · {reg.email}</div>
                          <div className="text-[10px] text-slate-400">Inscrit le {reg.registeredAt}</div>
                        </td>
                        <td className="py-3.5 px-3 font-semibold text-slate-800">
                          {reg.cityName}
                        </td>
                        <td className="py-3.5 px-3">
                          {reg.ambassadorName ? (
                            <div>
                              <div className="font-bold text-slate-900">{reg.ambassadorName}</div>
                              <span className="font-mono text-[11px] font-bold text-[#007A3D] bg-emerald-50 px-1.5 py-0.5 rounded">
                                {reg.referralCode}
                              </span>
                            </div>
                          ) : (
                            <span className="text-slate-400 italic">Direct (Sans code)</span>
                          )}
                        </td>
                        <td className="py-3.5 px-3">
                          <div className="font-extrabold text-slate-900">{(reg.amount ?? 35000).toLocaleString()} FCFA</div>
                          <div className="text-[11px] text-slate-500">{reg.paymentMethod}</div>
                        </td>
                        <td className="py-3.5 px-3">
                          {reg.status === 'validee' ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#007A3D] bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Validée · +2 000 FCFA crédités</span>
                            </span>
                          ) : reg.status === 'annulee' ? (
                            <span className="text-[11px] font-medium text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded-full">
                              Annulée
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                              <Clock className="w-3 h-3" />
                              <span>En attente validation</span>
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-3 text-right">
                          {reg.status === 'en_attente' ? (
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => validateRegistration(reg.id)}
                                className="px-3 py-1.5 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-1 cursor-pointer"
                                title="Valider l'inscription et créditer les 2 000 FCFA à l'ambassadeur"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Valider & Créditer</span>
                              </button>
                              <button
                                onClick={() => cancelRegistration(reg.id)}
                                className="px-2 py-1.5 bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-700 text-xs rounded-xl transition-colors cursor-pointer"
                                title="Annuler"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-medium">Validé</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 2: Ambassadeurs Officiels */}
        {activeTab === 'ambassadeurs' && (
          <div className="bg-white rounded-b-2xl border border-slate-200 p-6 shadow-2xs space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <h3 className="font-black text-slate-900 text-base">
                  Gestion des Ambassadeurs Officiels
                </h3>
                <p className="text-xs text-slate-500">
                  Les coordonnées des ambassadeurs doivent être ajoutées exclusivement par l'administrateur.
                </p>
              </div>

              <button
                onClick={() => setIsAddingAmbassador(true)}
                className="px-4 py-2.5 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-2 cursor-pointer self-start sm:self-auto"
              >
                <UserPlus className="w-4 h-4" />
                <span>+ Ajouter un ambassadeur officiel</span>
              </button>
            </div>

            {/* List of active ambassadors */}
            {activeAmbassadors.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300 space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-[#007A3D] flex items-center justify-center mx-auto">
                  <UserCheck className="w-6 h-6" />
                </div>
                <div className="max-w-md mx-auto space-y-1">
                  <h4 className="font-bold text-slate-900 text-sm">
                    Aucun ambassadeur officiel n'est encore configuré
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Toutes les fausses coordonnées d'exemples ont été purgées conformément aux consignes. Utilisez le bouton ci-dessous pour ajouter un ambassadeur officiel dès que ses informations sont fournies.
                  </p>
                </div>
                <button
                  onClick={() => setIsAddingAmbassador(true)}
                  className="px-4 py-2 bg-[#007A3D] hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer"
                >
                  Ajouter un ambassadeur officiel
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-3">Ambassadeur</th>
                      <th className="py-3 px-3">Ville & Quartier</th>
                      <th className="py-3 px-3">Bureau / Point Local</th>
                      <th className="py-3 px-3">Code Unique</th>
                      <th className="py-3 px-3 text-center">Filleuls Inscrits</th>
                      <th className="py-3 px-3 text-center">Inscrits Validés</th>
                      <th className="py-3 px-3 text-right">Solde Disponible</th>
                      <th className="py-3 px-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {activeAmbassadors.map((amb) => (
                      <tr key={amb.id} className="hover:bg-slate-50/70">
                        <td className="py-3.5 px-3">
                          <div className="font-extrabold text-slate-900">{amb.name}</div>
                          <div className="text-[11px] text-slate-500">{amb.phone} · {amb.email}</div>
                        </td>
                        <td className="py-3.5 px-3">
                          <div className="font-bold text-[#007A3D]">{amb.cityName}</div>
                          <div className="text-[11px] text-slate-500">{amb.neighborhood}</div>
                        </td>
                        <td className="py-3.5 px-3">
                          <div className="text-xs text-slate-700 max-w-xs line-clamp-2">{amb.officeAddress}</div>
                        </td>
                        <td className="py-3.5 px-3">
                          <span className="font-mono font-bold text-slate-900 bg-slate-100 border border-slate-200 px-2 py-1 rounded-lg">
                            {amb.referralCode}
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-center font-bold text-slate-800">
                          {amb.referredCount ?? 0}
                        </td>
                        <td className="py-3.5 px-3 text-center font-extrabold text-[#007A3D]">
                          {amb.validatedCount ?? 0}
                        </td>
                        <td className="py-3.5 px-3 text-right font-extrabold text-[#007A3D] tabular-nums">
                          {(amb.balanceAvailable ?? 0).toLocaleString()} FCFA
                        </td>
                        <td className="py-3.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setCurrentAmbassadorId(amb.id);
                                setUserRole('ambassador');
                                setCurrentSection('dashboard-ambassadeur');
                              }}
                              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-[#007A3D] text-[11px] font-bold rounded-lg transition-colors cursor-pointer"
                              title="Voir son tableau de bord"
                            >
                              Voir
                            </button>
                            <button
                              onClick={() => setEditingAmbassador(amb)}
                              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold rounded-lg transition-colors cursor-pointer"
                            >
                              Modifier
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* City Ambassador Mapping Status */}
            <div className="pt-4 border-t border-slate-100 space-y-3">
              <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                État d'affectation des 7 Villes Officielles
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {cities.map((city) => {
                  const assigned = ambassadors.find(
                    (a) => (a.cityId === city.id || a.id === city.ambassadorId) && a.status === 'actif'
                  );
                  const isAssigned = Boolean(assigned) || (city.ambassadorName && city.ambassadorName !== 'À renseigner');

                  return (
                    <div
                      key={city.id}
                      className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-bold text-slate-900">{city.name} ({city.code})</div>
                        <div className="text-[11px] text-slate-500">
                          {isAssigned ? (
                            <span className="text-[#007A3D] font-bold">
                              {assigned ? assigned.name : city.ambassadorName}
                            </span>
                          ) : (
                            <span className="italic text-slate-400">« À renseigner »</span>
                          )}
                        </div>
                      </div>

                      {isAssigned ? (
                        <button
                          onClick={() => removeAmbassadorFromCity(city.id)}
                          className="text-[11px] text-red-600 hover:underline cursor-pointer"
                          title="Remettre à 'À renseigner'"
                        >
                          Détacher
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            setNewAmbCityId(city.id);
                            setIsAddingAmbassador(true);
                          }}
                          className="px-2 py-1 bg-[#007A3D] text-white rounded text-[11px] font-bold cursor-pointer"
                        >
                          + Affecter
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* Tab 3: Candidatures en attente de validation */}
        {activeTab === 'candidatures' && (
          <div className="bg-white rounded-b-2xl border border-slate-200 p-6 shadow-2xs space-y-4">
            
            <div className="pb-3 border-b border-slate-100">
              <h3 className="font-black text-slate-900 text-base">
                Candidatures Ambassadeurs à Valider ({pendingAmbassadors.length})
              </h3>
              <p className="text-xs text-slate-500">
                Accepter une candidature crée et active automatiquement le compte ambassadeur avec son code officiel.
              </p>
            </div>

            {pendingAmbassadors.length === 0 ? (
              <div className="p-10 text-center text-xs text-slate-500 bg-slate-50 rounded-2xl">
                Aucune candidature en attente d'approbation.
              </div>
            ) : (
              <div className="space-y-4">
                {pendingAmbassadors.map((candidate) => (
                  <div
                    key={candidate.id}
                    className="p-5 rounded-2xl border-2 border-amber-200 bg-amber-50/30 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-slate-900 text-base">{candidate.name}</span>
                        <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full border border-amber-300">
                          En attente de validation
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 flex flex-wrap items-center gap-3">
                        <span>Ville visée : <strong className="text-slate-900">{candidate.cityName}</strong></span>
                        <span>·</span>
                        <span>Quartier : <strong className="text-slate-900">{candidate.neighborhood}</strong></span>
                        <span>·</span>
                        <span>Tél : {candidate.phone}</span>
                        <span>·</span>
                        <span>WhatsApp : {candidate.whatsapp}</span>
                      </div>
                      <div className="text-xs text-slate-700">
                        Bureau / Point local proposé : <strong>{candidate.officeAddress}</strong>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => approveAmbassador(candidate.id)}
                        className="px-4 py-2 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <UserCheck className="w-4 h-4" />
                        <span>Accepter la candidature</span>
                      </button>
                      <button
                        onClick={() => rejectAmbassador(candidate.id)}
                        className="px-3.5 py-2 bg-slate-100 hover:bg-red-50 text-red-600 font-bold text-xs rounded-xl transition-colors cursor-pointer"
                      >
                        Refuser
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>
        )}

        {/* Tab 4: Demandes de Retrait */}
        {activeTab === 'retraits' && (
          <div className="bg-white rounded-b-2xl border border-slate-200 p-6 shadow-2xs space-y-4">
            
            <div className="pb-3 border-b border-slate-100">
              <h3 className="font-black text-slate-900 text-base">
                Traitement des Demandes de Retrait Mobile Money
              </h3>
              <p className="text-xs text-slate-500">
                Vérification manuelle des commissions validées. Aucun débit automatique n'est exécuté.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-3">Réf / Date</th>
                    <th className="py-3 px-3">Ambassadeur</th>
                    <th className="py-3 px-3">Montant</th>
                    <th className="py-3 px-3">Opérateur & Numéro</th>
                    <th className="py-3 px-3">Titulaire Compte</th>
                    <th className="py-3 px-3">Statut</th>
                    <th className="py-3 px-3 text-right">Action Direction</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {withdrawals.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        Aucune demande de retrait enregistrée pour le moment.
                      </td>
                    </tr>
                  ) : (
                    withdrawals.map((wth) => (
                      <tr key={wth.id} className="hover:bg-slate-50/70">
                        <td className="py-3.5 px-3">
                          <div className="font-mono font-bold text-slate-900">{wth.id}</div>
                          <div className="text-[10px] text-slate-400">{wth.createdAt}</div>
                        </td>
                        <td className="py-3.5 px-3">
                          <div className="font-bold text-slate-900">{wth.ambassadorName}</div>
                          <div className="text-[11px] text-slate-500">{wth.cityName}</div>
                        </td>
                        <td className="py-3.5 px-3 font-extrabold text-slate-900 text-sm tabular-nums">
                          {(wth.amount ?? 0).toLocaleString()} FCFA
                        </td>
                        <td className="py-3.5 px-3">
                          <div className="font-bold text-slate-800">{wth.paymentMethod}</div>
                          <div className="text-[11px] font-mono text-slate-600">{wth.phone}</div>
                        </td>
                        <td className="py-3.5 px-3 font-semibold text-slate-800">
                          {wth.accountHolderName}
                        </td>
                        <td className="py-3.5 px-3">
                          {wth.status === 'validee' ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#007A3D] bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Validé (Payé le {wth.processedAt})</span>
                            </span>
                          ) : wth.status === 'rejetee' ? (
                            <span className="text-[11px] font-bold text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded-full">
                              Refusé & Remboursé
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                              <Clock className="w-3 h-3" />
                              <span>En attente</span>
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-3 text-right">
                          {wth.status === 'en_attente' ? (
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => processWithdrawal(wth.id, 'validee')}
                                className="px-3 py-1.5 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors cursor-pointer"
                              >
                                Valider le retrait
                              </button>
                              <button
                                onClick={() => processWithdrawal(wth.id, 'rejetee')}
                                className="px-2.5 py-1.5 bg-slate-100 hover:bg-red-50 text-red-600 text-xs rounded-xl transition-colors font-semibold cursor-pointer"
                              >
                                Refuser
                              </button>
                            </div>
                          ) : (
                            <span className="text-[11px] text-slate-400">Traité</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* Tab 5: Villes & Bureaux */}
        {activeTab === 'villes' && (
          <div className="bg-white rounded-b-2xl border border-slate-200 p-6 shadow-2xs space-y-6">
            
            <div className="pb-3 border-b border-slate-100">
              <h3 className="font-black text-slate-900 text-base">
                Gestion des 7 Villes & Sessions Présentielles
              </h3>
              <p className="text-xs text-slate-500">
                Actualisez les dates, les lieux de conférence et les bureaux d'accueil des 7 villes de la tournée.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {cities.map((city) => {
                const isEditing = editingCityId === city.id;
                return (
                  <div
                    key={city.id}
                    className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-[#CE1126]" />
                        <span className="font-extrabold text-slate-900 text-base">{city.name}</span>
                        <span className="text-xs font-mono font-bold text-slate-400">({city.code})</span>
                        <span className="text-xs text-slate-500">· {city.region}</span>
                      </div>
                      {!isEditing ? (
                        <button
                          onClick={() => handleStartEditCity(city)}
                          className="p-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg text-slate-600 text-xs flex items-center gap-1 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>Modifier</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleSaveEditCity(city.id)}
                          className="px-2.5 py-1 bg-[#007A3D] text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs cursor-pointer"
                        >
                          <Save className="w-3.5 h-3.5" />
                          <span>Enregistrer</span>
                        </button>
                      )}
                    </div>

                    {!isEditing ? (
                      <div className="space-y-1.5 text-xs text-slate-600">
                        <div>
                          <strong className="text-slate-900">Session en présentiel :</strong> {city.nextSessionDate} ({city.nextSessionTime})
                        </div>
                        <div>
                          <strong className="text-slate-900">Lieu de conférence :</strong>{' '}
                          <span className={city.venueName === 'À renseigner' ? 'italic text-slate-400' : ''}>
                            {city.venueName}
                          </span>
                        </div>
                        <div>
                          <strong className="text-slate-900">Bureau local / Point officiel :</strong>{' '}
                          <span className={city.officeAddress === 'À renseigner' ? 'italic text-slate-400' : ''}>
                            {city.officeAddress}
                          </span>
                        </div>
                        <div className="pt-2 text-slate-500 flex justify-between border-t border-slate-200">
                          <span>
                            Ambassadeur :{' '}
                            <strong className={city.ambassadorName === 'À renseigner' ? 'text-slate-500 italic' : 'text-slate-900'}>
                              {city.ambassadorName}
                            </strong>{' '}
                            {city.ambassadorPhone && city.ambassadorPhone !== 'À renseigner' ? `(${city.ambassadorPhone})` : ''}
                          </span>
                          <span className="font-bold text-[#007A3D]">{city.availableSeats} places libres</span>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2 pt-2">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700">Date de session :</label>
                          <input
                            type="text"
                            value={editedDate}
                            onChange={(e) => setEditedDate(e.target.value)}
                            className="w-full text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700">Lieu de formation :</label>
                          <input
                            type="text"
                            value={editedVenue}
                            onChange={(e) => setEditedVenue(e.target.value)}
                            placeholder="À renseigner"
                            className="w-full text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700">Bureau local officiel :</label>
                          <input
                            type="text"
                            value={editedOffice}
                            onChange={(e) => setEditedOffice(e.target.value)}
                            placeholder="À renseigner"
                            className="w-full text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700">Nom ambassadeur :</label>
                            <input
                              type="text"
                              value={editedAmbName}
                              onChange={(e) => setEditedAmbName(e.target.value)}
                              placeholder="À renseigner"
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700">Tél ambassadeur :</label>
                            <input
                              type="text"
                              value={editedAmbPhone}
                              onChange={(e) => setEditedAmbPhone(e.target.value)}
                              placeholder="À renseigner"
                              className="w-full text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

          </div>
        )}

        {/* Tab 6: Direction & Coordonnées du PDG (Modifiables uniquement par l'administrateur) */}
        {activeTab === 'direction' && (
          <div className="bg-white rounded-b-2xl border border-slate-200 p-6 shadow-2xs space-y-6">
            
            <div className="pb-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-[#007A3D] uppercase tracking-wider flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-[#CE1126]" />
                  <span>Direction Générale · IMPORTPRO CAMEROUN</span>
                </div>
                <h3 className="font-black text-slate-900 text-lg mt-0.5">
                  Coordonnées Officielles du Fondateur & PDG
                </h3>
                <p className="text-xs text-slate-500">
                  Modifiables uniquement par l'administrateur. Les champs laissés vides affichent automatiquement « À renseigner ».
                </p>
              </div>

              <div className="hidden sm:block text-right">
                <span className="inline-flex items-center gap-1 bg-emerald-50 text-[#007A3D] border border-emerald-200 px-3 py-1 rounded-full text-xs font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Identité Vérifiée</span>
                </span>
              </div>
            </div>

            <form onSubmit={handleSaveCeoSubmit} className="max-w-2xl space-y-4">
              
              {/* Titre & Nom (Strictement conservé) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">Titre Officiel :</label>
                  <div className="font-extrabold text-slate-900 text-sm">
                    {ceoInfo.title}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">Nom du PDG / Fondateur :</label>
                  <div className="font-extrabold text-slate-900 text-sm text-[#007A3D]">
                    {ceoInfo.name}
                  </div>
                </div>
              </div>

              {/* Téléphone officiel */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Numéro de téléphone officiel du PDG :
                </label>
                <input
                  type="text"
                  placeholder="Laisser vide pour afficher « À renseigner »"
                  value={ceoPhone}
                  onChange={(e) => setCeoPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                />
              </div>

              {/* WhatsApp officiel */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Numéro WhatsApp officiel du PDG :
                </label>
                <input
                  type="text"
                  placeholder="Laisser vide pour afficher « À renseigner »"
                  value={ceoWhatsapp}
                  onChange={(e) => setCeoWhatsapp(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                />
              </div>

              {/* Email officiel */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Adresse e-mail officielle de la direction :
                </label>
                <input
                  type="text"
                  placeholder="Laisser vide pour afficher « À renseigner »"
                  value={ceoEmail}
                  onChange={(e) => setCeoEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                />
              </div>

              {/* Adresse du Siège / Bureau */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Adresse officielle du bureau de la direction / Siège :
                </label>
                <input
                  type="text"
                  placeholder="Laisser vide pour afficher « À renseigner »"
                  value={ceoOffice}
                  onChange={(e) => setCeoOffice(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                />
              </div>

              {/* Ville */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Ville du siège principal :
                </label>
                <input
                  type="text"
                  placeholder="Laisser vide pour afficher « À renseigner »"
                  value={ceoCity}
                  onChange={(e) => setCeoCity(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs text-slate-900 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-2xs transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Enregistrer les coordonnées officielles du PDG</span>
                </button>
              </div>

            </form>

          </div>
        )}

        {/* Modal: Add Official Ambassador */}
        {isAddingAmbassador && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <div>
                  <h3 className="font-black text-slate-900 text-base">
                    Ajouter un Ambassadeur Officiel
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Ces coordonnées officielles seront publiées sur le site et affectées à la ville sélectionnée.
                  </p>
                </div>
                <button
                  onClick={() => setIsAddingAmbassador(false)}
                  className="text-slate-400 hover:text-slate-600 text-lg leading-none cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleCreateAmbassadorSubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Nom complet de l'ambassadeur * :
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Nom officiel"
                    value={newAmbName}
                    onChange={(e) => setNewAmbName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Téléphone * :</label>
                    <input
                      type="tel"
                      required
                      placeholder="+237 6XX XX XX XX"
                      value={newAmbPhone}
                      onChange={(e) => setNewAmbPhone(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">WhatsApp :</label>
                    <input
                      type="tel"
                      placeholder="+237 6XX XX XX XX"
                      value={newAmbWhatsapp}
                      onChange={(e) => setNewAmbWhatsapp(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Adresse Email :</label>
                  <input
                    type="text"
                    placeholder="À renseigner ou email officiel"
                    value={newAmbEmail}
                    onChange={(e) => setNewAmbEmail(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Ville officielle * :</label>
                    <select
                      value={newAmbCityId}
                      onChange={(e) => setNewAmbCityId(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white font-semibold"
                    >
                      {cities.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} ({c.code})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Quartier * :</label>
                    <input
                      type="text"
                      placeholder="Quartier ou secteur"
                      value={newAmbNeighborhood}
                      onChange={(e) => setNewAmbNeighborhood(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Adresse précise du bureau / point local * :
                  </label>
                  <input
                    type="text"
                    placeholder="Adresse officielle d'accueil"
                    value={newAmbOffice}
                    onChange={(e) => setNewAmbOffice(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Code de parrainage (Optionnel) :</label>
                    <input
                      type="text"
                      placeholder="Génération automatique"
                      value={newAmbCode}
                      onChange={(e) => setNewAmbCode(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl uppercase font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Mot de passe de session :</label>
                    <input
                      type="password"
                      placeholder="Par défaut: ambassadeur123"
                      value={newAmbPassword}
                      onChange={(e) => setNewAmbPassword(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>
                </div>

                <div className="pt-3 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsAddingAmbassador(false)}
                    className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold rounded-xl shadow-2xs transition-colors cursor-pointer"
                  >
                    Créer l'ambassadeur officiel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal: Edit Ambassador */}
        {editingAmbassador && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <h3 className="font-black text-slate-900 text-base">
                  Modifier les Coordonnées de l'Ambassadeur
                </h3>
                <button
                  onClick={() => setEditingAmbassador(null)}
                  className="text-slate-400 hover:text-slate-600 text-lg leading-none cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleSaveAmbassadorEdits} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Nom complet :</label>
                  <input
                    type="text"
                    required
                    value={editingAmbassador.name}
                    onChange={(e) => setEditingAmbassador({ ...editingAmbassador, name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Téléphone :</label>
                    <input
                      type="tel"
                      required
                      value={editingAmbassador.phone}
                      onChange={(e) => setEditingAmbassador({ ...editingAmbassador, phone: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">WhatsApp :</label>
                    <input
                      type="tel"
                      value={editingAmbassador.whatsapp}
                      onChange={(e) => setEditingAmbassador({ ...editingAmbassador, whatsapp: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email :</label>
                  <input
                    type="text"
                    value={editingAmbassador.email}
                    onChange={(e) => setEditingAmbassador({ ...editingAmbassador, email: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Ville :</label>
                    <select
                      value={editingAmbassador.cityId}
                      onChange={(e) => setEditingAmbassador({ ...editingAmbassador, cityId: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-white font-semibold"
                    >
                      {cities.map((c) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Quartier :</label>
                    <input
                      type="text"
                      value={editingAmbassador.neighborhood}
                      onChange={(e) => setEditingAmbassador({ ...editingAmbassador, neighborhood: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Adresse Bureau / Point Local :</label>
                  <input
                    type="text"
                    value={editingAmbassador.officeAddress}
                    onChange={(e) => setEditingAmbassador({ ...editingAmbassador, officeAddress: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setEditingAmbassador(null)}
                    className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold rounded-xl shadow-2xs transition-colors cursor-pointer"
                  >
                    Enregistrer les modifications
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
