import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, UserCheck, Shield, Users, ArrowRight } from 'lucide-react';

export const LoginModal: React.FC = () => {
  const {
    isLoginModalOpen,
    closeLoginModal,
    ambassadors,
    setUserRole,
    setCurrentAmbassadorId,
    setCurrentSection,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'ambassadeur' | 'admin' | 'visiteur'>('ambassadeur');
  const [selectedAmbId, setSelectedAmbId] = useState(ambassadors[0]?.id || '');

  if (!isLoginModalOpen) return null;

  const handleLoginAsAmbassador = () => {
    if (!selectedAmbId && ambassadors.length > 0) {
      setSelectedAmbId(ambassadors[0].id);
    }
    const targetId = selectedAmbId || (ambassadors[0] ? ambassadors[0].id : '');
    if (!targetId) {
      showToast('Aucun ambassadeur', 'Veuillez d\'abord ajouter un ambassadeur depuis l\'espace Admin.', 'warning');
      return;
    }
    setUserRole('ambassador');
    setCurrentAmbassadorId(targetId);
    closeLoginModal();
    setCurrentSection('dashboard-ambassadeur');
    const amb = ambassadors.find((a) => a.id === targetId);
    showToast('Connexion réussie', `Connecté en tant qu'ambassadeur de ${amb?.cityName} (${amb?.name}).`);
  };

  const handleLoginAsAdmin = () => {
    setUserRole('admin');
    closeLoginModal();
    setCurrentSection('dashboard-admin');
    showToast('Accès Direction', 'Connecté en tant qu\'administrateur général ImportPro.');
  };

  const handleLoginAsVisitor = () => {
    setUserRole('visitor');
    closeLoginModal();
    setCurrentSection('accueil');
    showToast('Mode Visiteur', 'Connecté en tant que visiteur.');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative">
        
        {/* Close Button */}
        <button
          onClick={closeLoginModal}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 p-1"
          aria-label="Fermer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-5">
          <div className="text-[11px] font-bold uppercase tracking-wider text-[#007A3D] mb-1">
            IMPORTPRO CAMEROUN
          </div>
          <h2 className="text-xl font-extrabold text-slate-900">
            Connexion à votre Espace
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Accédez à votre tableau de bord selon votre profil.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex border border-slate-200 rounded-xl p-1 bg-slate-50 mb-5 text-xs font-bold">
          <button
            onClick={() => setActiveTab('ambassadeur')}
            className={`flex-1 py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'ambassadeur'
                ? 'bg-white text-[#007A3D] shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Ambassadeur</span>
          </button>
          <button
            onClick={() => setActiveTab('admin')}
            className={`flex-1 py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'admin'
                ? 'bg-white text-[#CE1126] shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Direction Admin</span>
          </button>
          <button
            onClick={() => setActiveTab('visiteur')}
            className={`flex-1 py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'visiteur'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Visiteur</span>
          </button>
        </div>

        {activeTab === 'ambassadeur' && (
          <div className="space-y-4">
            {ambassadors.filter((a) => a.status === 'actif').length === 0 ? (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 text-center space-y-2">
                <p>Aucun compte ambassadeur officiel n'est encore configuré.</p>
                <button
                  type="button"
                  onClick={() => setActiveTab('admin')}
                  className="text-xs font-bold text-[#007A3D] hover:underline cursor-pointer"
                >
                  Ajouter un ambassadeur depuis l'espace Admin →
                </button>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Sélectionnez votre compte ambassadeur :
                </label>
                <select
                  value={selectedAmbId}
                  onChange={(e) => setSelectedAmbId(e.target.value)}
                  className="w-full px-3 py-2.5 text-xs font-semibold text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                >
                  {ambassadors
                    .filter((a) => a.status === 'actif')
                    .map((amb) => (
                      <option key={amb.id} value={amb.id}>
                        {amb.cityName} — {amb.name} ({amb.referralCode})
                      </option>
                    ))}
                </select>
              </div>
            )}

            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100 text-xs text-slate-600">
              Accédez à vos liens de parrainage, commissions accumulées (2 000 FCFA / personne validée) et demandes de retrait Orange / MTN Mobile Money.
            </div>

            {ambassadors.filter((a) => a.status === 'actif').length > 0 && (
              <button
                onClick={handleLoginAsAmbassador}
                className="w-full py-2.5 bg-[#007A3D] hover:bg-emerald-800 text-white font-bold text-xs rounded-lg shadow-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Accéder au Tableau de Bord Ambassadeur</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {activeTab === 'admin' && (
          <div className="space-y-4">
            <div className="p-3 bg-red-50 rounded-xl border border-red-100 text-xs text-slate-700">
              <strong className="text-[#CE1126] block font-bold mb-1">
                Espace Direction Générale ImportPro
              </strong>
              Permet de valider les inscriptions, créditer automatiquement les 2 000 FCFA aux ambassadeurs, payer les retraits et ajuster les dates de formation des 7 villes.
            </div>

            <button
              onClick={handleLoginAsAdmin}
              className="w-full py-2.5 bg-[#CE1126] hover:bg-red-800 text-white font-bold text-xs rounded-lg shadow-sm transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Entrer dans le Panneau d'Administration</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {activeTab === 'visiteur' && (
          <div className="space-y-4">
            <p className="text-xs text-slate-600">
              Naviguez librement sur le site, découvrez le programme de formation physique, les dates de votre ville et les produits importés à fort rendement.
            </p>
            <button
              onClick={handleLoginAsVisitor}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-lg shadow-sm transition-colors"
            >
              Continuer comme Candidat / Visiteur
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
