import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Users,
  CheckCircle2,
  DollarSign,
  Wallet,
  Copy,
  Share2,
  ArrowUpRight,
  Clock,
  Building2,
  MapPin,
  Phone,
  AlertCircle,
  Sparkles,
  ArrowLeft,
  Shield,
  Lock,
  UserCheck,
  CreditCard
} from 'lucide-react';

export const AmbassadorDashboard: React.FC = () => {
  const {
    currentAmbassador,
    ambassadors,
    setCurrentAmbassadorId,
    registrations,
    withdrawals,
    requestWithdrawal,
    showToast,
    setCurrentSection,
    userRole,
    setUserRole
  } = useApp();

  const [withdrawModalOpen, setWithdrawModalOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState<number>(2000);
  const [withdrawMethod, setWithdrawMethod] = useState<'Orange Money' | 'MTN Mobile Money'>('Orange Money');
  const [withdrawPhone, setWithdrawPhone] = useState(
    currentAmbassador?.phone && currentAmbassador.phone !== 'À renseigner' ? currentAmbassador.phone : ''
  );
  const [accountHolderName, setAccountHolderName] = useState(
    currentAmbassador?.name && currentAmbassador.name !== 'À renseigner' ? currentAmbassador.name : ''
  );
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Security: if not ambassador or no current ambassador, show lock/auth prompt
  if (!currentAmbassador) {
    return (
      <div className="min-h-screen py-16 bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 max-w-md w-full text-center space-y-4 shadow-sm">
          <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-lg font-extrabold text-slate-900">Espace Ambassadeur</h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            Aucun ambassadeur officiel n'est actuellement configuré. Les coordonnées des ambassadeurs doivent être ajoutées par l'administrateur depuis l'espace Administration.
          </p>
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => {
                setUserRole('admin');
                setCurrentSection('dashboard-admin');
              }}
              className="px-4 py-2.5 bg-[#007A3D] hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Aller dans l'Espace Administration
            </button>
            <button
              onClick={() => setCurrentSection('accueil')}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              Retour à l'accueil
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Security isolation: STRICTLY filter to ONLY this ambassador's data
  const myRegistrations = registrations.filter(
    (r) =>
      r.ambassadorId === currentAmbassador.id ||
      (r.referralCode && r.referralCode.toUpperCase() === currentAmbassador.referralCode.toUpperCase())
  );

  const myWithdrawals = withdrawals.filter(
    (w) => w.ambassadorId === currentAmbassador.id
  );

  // Calculations
  const registeredCount = myRegistrations.length;
  const validatedCount = myRegistrations.filter((r) => r.status === 'validee').length;
  const pendingCount = myRegistrations.filter((r) => r.status === 'en_attente').length;
  const pendingCommissions = pendingCount * 2000;
  const availableBalance = currentAmbassador.balanceAvailable ?? 0;
  const totalCommissions = currentAmbassador.totalCommissions ?? (currentAmbassador as any).commissionEarned ?? (validatedCount * 2000);

  // Clean full referral link
  const referralLink = `${window.location.origin}/?ref=${currentAmbassador.referralCode}`;

  const copyReferralCode = () => {
    navigator.clipboard.writeText(currentAmbassador.referralCode);
    showToast('Code copié !', `Le code ${currentAmbassador.referralCode} a été copié.`);
  };

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
    showToast('Lien copié !', `Votre lien unique ${referralLink} a été copié.`);
  };

  const shareOnWhatsApp = () => {
    const text = encodeURIComponent(
      `👋 Bonjour ! Inscris-toi à la formation physique d'importation Chine-Cameroun animée en présentiel par le fondateur à ${currentAmbassador.cityName}.\n\nUtilise mon code officiel : *${currentAmbassador.referralCode}*\nNotre bureau local : ${currentAmbassador.officeAddress} (${currentAmbassador.neighborhood})\n\nLien d'inscription directe : ${referralLink}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const result = requestWithdrawal({
      ambassadorId: currentAmbassador.id,
      amount: Number(withdrawAmount),
      paymentMethod: withdrawMethod,
      phone: withdrawPhone,
      accountHolderName: accountHolderName.trim() || currentAmbassador.name
    });

    setIsSubmitting(false);
    if (result.success) {
      setWithdrawModalOpen(false);
    }
  };

  return (
    <div className="py-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Top Header & Fast Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setCurrentSection('accueil')}
              className="p-2 bg-white rounded-lg border border-slate-200 text-slate-600 hover:text-slate-900 transition-colors shadow-2xs cursor-pointer"
              title="Retour à l'accueil"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <div className="text-xs font-bold text-[#007A3D] uppercase tracking-wider flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-[#007A3D]" />
                <span>Espace Ambassadeur Protégé · Données strictement personnelles</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Tableau de Bord — {currentAmbassador.name}
              </h1>
            </div>
          </div>

          {/* Quick Ambassador Switcher for Evaluation */}
          <div className="flex items-center gap-2 bg-white p-1.5 rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-xs text-slate-500 font-semibold pl-2">Session :</span>
            <select
              value={currentAmbassador.id}
              onChange={(e) => {
                setCurrentAmbassadorId(e.target.value);
                const selected = ambassadors.find((a) => a.id === e.target.value);
                if (selected) {
                  setWithdrawPhone(selected.phone);
                  setAccountHolderName(selected.name);
                }
              }}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
            >
              {ambassadors.filter(a => a.status === 'actif').map((a) => (
                <option key={a.id} value={a.id}>
                  {a.cityName} — {a.name} ({a.referralCode})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Identity & Office Card */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-2xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            
            {/* Left: Info Profile */}
            <div className="lg:col-span-6 flex items-start gap-4">
              <div className="w-16 h-16 rounded-2xl bg-[#007A3D] text-white flex items-center justify-center font-display font-black text-2xl shadow-sm shrink-0">
                {currentAmbassador.name.charAt(0)}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">
                    {currentAmbassador.name}
                  </h2>
                  <span className="text-[10px] bg-emerald-100 text-[#007A3D] font-extrabold px-2 py-0.5 rounded-full border border-emerald-200">
                    Ambassadeur Officiel
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
                  <div className="flex items-center gap-1 font-bold text-slate-800">
                    <MapPin className="w-3.5 h-3.5 text-[#CE1126]" />
                    <span>{currentAmbassador.cityName}</span>
                    <span className="text-slate-400 font-normal">({currentAmbassador.neighborhood})</span>
                  </div>
                  <span>·</span>
                  <div className="flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{currentAmbassador.phone}</span>
                  </div>
                </div>
                <div className="flex items-start gap-1.5 text-xs text-slate-500 pt-1">
                  <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                  <span>Bureau officiel : <strong>{currentAmbassador.officeAddress}</strong></span>
                </div>
              </div>
            </div>

            {/* Right: Unique Referral Code & Link */}
            <div className="lg:col-span-6 bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-extrabold text-slate-700">Code & Lien de Parrainage Unique</span>
                <span className="text-[11px] font-extrabold text-[#007A3D] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  2 000 FCFA / personne validée
                </span>
              </div>

              {/* Code Box */}
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-white border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono font-black text-slate-900 tracking-wider">
                  {currentAmbassador.referralCode}
                </div>
                <button
                  onClick={copyReferralCode}
                  className="px-3.5 py-2 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  title="Copier le code"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Code</span>
                </button>
                <button
                  onClick={copyReferralLink}
                  className="px-3.5 py-2 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  title="Copier le lien"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Lien</span>
                </button>
                <button
                  onClick={shareOnWhatsApp}
                  className="px-3.5 py-2 bg-[#25D366] hover:bg-emerald-600 text-white text-xs font-black rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
                  title="Partager sur WhatsApp"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>
              </div>

              <div className="text-[11px] text-slate-500">
                Toute personne s'inscrivant via votre lien ou en mentionnant ce code vous est automatiquement attribuée.
              </div>
            </div>

          </div>
        </div>

        {/* 5 Core Metrics requested by user */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          
          {/* 1. Nombre de personnes inscrites */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-500">Personnes inscrites</span>
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
              {registeredCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Affiliés via votre code
            </div>
          </div>

          {/* 2. Nombre d'inscriptions validées */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-500">Inscriptions validées</span>
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-[#007A3D] flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#007A3D] tabular-nums">
              {validatedCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Confirmées par l'admin
            </div>
          </div>

          {/* 3. Commissions en attente */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-500">Commissions en attente</span>
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-700 tabular-nums">
              {(pendingCommissions ?? 0).toLocaleString()} <span className="text-xs font-bold">FCFA</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {pendingCount} en attente de validation
            </div>
          </div>

          {/* 4. Commissions disponibles */}
          <div className="bg-white rounded-2xl border-2 border-[#007A3D] p-5 shadow-2xs bg-gradient-to-br from-white to-emerald-50/40">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#007A3D]">Commissions disponibles</span>
              <div className="w-8 h-8 rounded-lg bg-[#007A3D] text-white flex items-center justify-center">
                <Wallet className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#007A3D] tabular-nums">
              {(availableBalance ?? 0).toLocaleString()} <span className="text-xs font-bold">FCFA</span>
            </div>
            <div className="mt-3">
              <button
                onClick={() => {
                  setWithdrawAmount(availableBalance >= 2000 ? availableBalance : 2000);
                  setWithdrawPhone(currentAmbassador.phone);
                  setAccountHolderName(currentAmbassador.name);
                  setWithdrawModalOpen(true);
                }}
                disabled={availableBalance < 2000}
                className="w-full py-2 px-3 bg-[#007A3D] hover:bg-emerald-800 disabled:bg-slate-300 disabled:cursor-not-allowed text-white text-xs font-bold rounded-xl shadow-2xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Demander un retrait</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* 5. Total des commissions */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs col-span-2 lg:col-span-1">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-500">Total des commissions</span>
              <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
              {(totalCommissions ?? 0).toLocaleString()} <span className="text-xs font-bold text-slate-400">FCFA</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Gains cumulés historiques
            </div>
          </div>

        </div>

        {/* Withdrawal Modal */}
        {withdrawModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
              
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <div>
                  <h3 className="font-black text-slate-900 text-base">
                    Demander un Retrait
                  </h3>
                  <p className="text-xs text-slate-500">
                    Solde disponible : <strong className="text-[#007A3D]">{(availableBalance ?? 0).toLocaleString()} FCFA</strong>
                  </p>
                </div>
                <button
                  onClick={() => setWithdrawModalOpen(false)}
                  className="text-slate-400 hover:text-slate-600 text-lg leading-none cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleWithdrawSubmit} className="space-y-4">
                
                {/* Montant */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Montant du retrait (FCFA) * :
                  </label>
                  <input
                    type="number"
                    min="2000"
                    max={availableBalance}
                    step="1000"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                    required
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                  <span className="text-[11px] text-slate-500 mt-0.5 block">
                    Minimum : 2 000 FCFA · Maximum : {(availableBalance ?? 0).toLocaleString()} FCFA
                  </span>
                </div>

                {/* Orange Money ou MTN Mobile Money */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Opérateur Mobile Money * :
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setWithdrawMethod('Orange Money')}
                      className={`p-3 rounded-xl border text-xs font-extrabold flex flex-col items-center gap-1 transition-colors cursor-pointer ${
                        withdrawMethod === 'Orange Money'
                          ? 'border-orange-500 bg-orange-50 text-orange-950 ring-2 ring-orange-500'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <span className="w-3 h-3 rounded-full bg-orange-500" />
                      <span>Orange Money</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setWithdrawMethod('MTN Mobile Money')}
                      className={`p-3 rounded-xl border text-xs font-extrabold flex flex-col items-center gap-1 transition-colors cursor-pointer ${
                        withdrawMethod === 'MTN Mobile Money'
                          ? 'border-yellow-500 bg-yellow-50 text-yellow-950 ring-2 ring-yellow-500'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <span className="w-3 h-3 rounded-full bg-[#FCD116]" />
                      <span>MTN Mobile Money</span>
                    </button>
                  </div>
                </div>

                {/* Numéro de paiement */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Numéro de paiement (+237) * :
                  </label>
                  <input
                    type="tel"
                    required
                    value={withdrawPhone}
                    onChange={(e) => setWithdrawPhone(e.target.value)}
                    placeholder="+237 6XX XX XX XX"
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                </div>

                {/* Nom du titulaire */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nom du titulaire du compte * :
                  </label>
                  <input
                    type="text"
                    required
                    value={accountHolderName}
                    onChange={(e) => setAccountHolderName(e.target.value)}
                    placeholder="Nom tel qu'enregistré chez l'opérateur"
                    className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                </div>

                <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-[11px] text-amber-900 leading-snug">
                  La demande sera enregistrée avec le statut <strong>« En attente »</strong>. L'administrateur vérifiera les inscriptions validées avant de procéder au virement.
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setWithdrawModalOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting || withdrawAmount < 2000 || withdrawAmount > availableBalance}
                    className="px-6 py-2.5 bg-[#007A3D] hover:bg-emerald-800 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl shadow-2xs transition-colors cursor-pointer"
                  >
                    {isSubmitting ? 'Traitement...' : 'Confirmer la demande'}
                  </button>
                </div>
              </form>

            </div>
          </div>
        )}

        {/* Tables: Historique des commissions / Filleuls & Retraits */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Historique des personnes inscrites & Commissions */}
          <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-black text-slate-900 text-base">
                  Historique des Commissions & Filleuls ({registeredCount})
                </h3>
                <p className="text-xs text-slate-500">
                  Personnes ayant utilisé votre lien ou code {currentAmbassador.referralCode}
                </p>
              </div>
              <div className="text-xs font-extrabold text-[#007A3D] bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                {validatedCount} validées
              </div>
            </div>

            {myRegistrations.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-xs text-slate-600 font-medium">
                  Aucun filleul inscrit avec votre code pour le moment.
                </p>
                <button
                  onClick={shareOnWhatsApp}
                  className="mt-3 text-xs font-bold text-[#007A3D] hover:underline cursor-pointer"
                >
                  Partager votre code sur WhatsApp pour commencer
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3">Filleul</th>
                      <th className="py-2.5 px-3">Date</th>
                      <th className="py-2.5 px-3">Statut Inscription</th>
                      <th className="py-2.5 px-3 text-right">Commission</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {myRegistrations.map((reg) => (
                      <tr key={reg.id} className="hover:bg-slate-50/80">
                        <td className="py-3 px-3">
                          <div className="font-bold text-slate-900">{reg.fullName}</div>
                          <div className="text-[11px] text-slate-500">{reg.phone}</div>
                        </td>
                        <td className="py-3 px-3 text-slate-600">
                          {reg.registeredAt}
                        </td>
                        <td className="py-3 px-3">
                          {reg.status === 'validee' ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#007A3D] bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Validée</span>
                            </span>
                          ) : reg.status === 'annulee' ? (
                            <span className="text-[11px] font-medium text-red-600 bg-red-50 px-2.5 py-0.5 rounded-full border border-red-200">
                              Annulée
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                              <Clock className="w-3 h-3" />
                              <span>En attente validation admin</span>
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-right font-extrabold tabular-nums">
                          {reg.status === 'validee' ? (
                            <span className="text-[#007A3D]">+2 000 FCFA (Créditée)</span>
                          ) : (
                            <span className="text-amber-700">2 000 FCFA (En attente)</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Right Column: Historique des Demandes de Retrait */}
          <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-6 shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-black text-slate-900 text-base">
                  Historique des Retraits ({myWithdrawals.length})
                </h3>
                <p className="text-xs text-slate-500">
                  Versements Orange Money & MTN MoMo
                </p>
              </div>
              <button
                onClick={() => setWithdrawModalOpen(true)}
                disabled={availableBalance < 2000}
                className="text-xs font-bold text-[#007A3D] hover:underline disabled:text-slate-300 cursor-pointer"
              >
                + Nouveau retrait
              </button>
            </div>

            {myWithdrawals.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                <Wallet className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-xs text-slate-600 font-medium">
                  Aucune demande de retrait effectuée pour le moment.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {myWithdrawals.map((w) => (
                  <div
                    key={w.id}
                    className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/50 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-extrabold text-slate-900 text-sm tabular-nums">
                        {(w.amount ?? 0).toLocaleString()} FCFA
                      </div>
                      <div className="text-[11px] text-slate-600 font-medium">
                        {w.paymentMethod} · {w.phone}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Titulaire : {w.accountHolderName} · {w.createdAt}
                      </div>
                    </div>
                    <div>
                      {w.status === 'validee' ? (
                        <span className="text-[11px] font-bold text-[#007A3D] bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full">
                          Validé
                        </span>
                      ) : w.status === 'rejetee' ? (
                        <span className="text-[11px] font-bold text-red-600 bg-red-50 border border-red-200 px-2.5 py-1 rounded-full">
                          Refusé
                        </span>
                      ) : (
                        <span className="text-[11px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-full">
                          En attente
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
