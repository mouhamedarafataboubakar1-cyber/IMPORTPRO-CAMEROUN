import React from 'react';
import { useApp } from '../context/AppContext';
import { MapPin, Phone, Mail, Building2, ShieldCheck, ArrowRight } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setCurrentSection, openRegistrationModal, openAmbassadorModal, ceoInfo } = useApp();

  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#007A3D] text-white flex items-center justify-center font-display font-bold text-sm">
                  IP
                </div>
                <h3 className="font-display font-extrabold text-xl tracking-tight text-white">
                  IMPORTPRO CAMEROUN
                </h3>
              </div>
              <div className="text-sm font-bold text-[#FCD116] tracking-wide mt-1.5">
                Apprendre. Importer. Revendre.
              </div>
              <div className="text-xs text-emerald-300 font-semibold mt-1">
                Formation physique • Importation • Revente • Ambassadeurs
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Première plateforme camerounaise de formations physiques en présentiel dispensées en direct par le fondateur sur l'importation directe Chine-Cameroun (1688, Taobao, Yiwu, Alibaba) et réseau d'ambassadeurs officiels dans les 7 villes.
            </p>

            {/* Official CEO / Direction Card */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 space-y-1.5 text-xs">
              <div className="font-extrabold text-white flex items-center justify-between">
                <span className="text-[#FCD116]">{ceoInfo.title}</span>
                <span className="text-white">{ceoInfo.name}</span>
              </div>
              <div className="text-[11px] text-slate-400 space-y-1 pt-1">
                <div className="flex items-center justify-between">
                  <span>Téléphone :</span>
                  <span className={ceoInfo.phone === 'À renseigner' ? 'italic text-slate-500' : 'text-slate-200 font-medium'}>
                    {ceoInfo.phone}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span>WhatsApp :</span>
                  <span className={ceoInfo.whatsapp === 'À renseigner' ? 'italic text-slate-500' : 'text-slate-200 font-medium'}>
                    {ceoInfo.whatsapp}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Bureau / Siège :</span>
                  <span className={ceoInfo.officeAddress === 'À renseigner' ? 'italic text-slate-500' : 'text-slate-200 font-medium'}>
                    {ceoInfo.officeAddress}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-1 flex items-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-[#007A3D]" />
              <span>Suivi post-formation garanti & réseau certifié.</span>
            </div>
          </div>

          {/* Nav Links */}
          <div className="space-y-3 text-xs">
            <div className="text-xs font-bold text-white uppercase tracking-wider">
              Navigation
            </div>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setCurrentSection('accueil')}
                  className="hover:text-white transition-colors"
                >
                  Accueil
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentSection('formation')}
                  className="hover:text-white transition-colors"
                >
                  Programme de Formation
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentSection('villes')}
                  className="hover:text-white transition-colors"
                >
                  Les 7 Villes & Bureaux
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentSection('ambassadeurs')}
                  className="hover:text-white transition-colors"
                >
                  Programme Ambassadeurs (2 000 FCFA)
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentSection('produits')}
                  className="hover:text-white transition-colors"
                >
                  Catalogue Produits Rentables
                </button>
              </li>
            </ul>
          </div>

          {/* The 7 Cities */}
          <div className="space-y-3 text-xs">
            <div className="text-xs font-bold text-white uppercase tracking-wider">
              Villes & Bureaux
            </div>
            <ul className="space-y-1.5 text-slate-400">
              <li>• Ngaoundéré (Adamaoua)</li>
              <li>• Maroua (Extrême-Nord)</li>
              <li>• Bertoua (Est)</li>
              <li>• Garoua-Boulaï (Est / Frontière RCA)</li>
              <li>• Pitoa (Nord)</li>
              <li>• Guider (Nord / Mayo-Louti)</li>
              <li>• Figuil (Nord / Bassin Industriel)</li>
            </ul>
          </div>

          {/* Quick Actions & Contact */}
          <div className="space-y-3 text-xs">
            <div className="text-xs font-bold text-white uppercase tracking-wider">
              Contact & Inscription
            </div>
            <p className="text-slate-400 leading-snug">
              Inscriptions ouvertes pour les prochaines sessions de formation physique.
            </p>
            <div className="space-y-2 pt-1">
              <button
                onClick={() => openRegistrationModal()}
                className="w-full py-2 px-3 bg-[#007A3D] hover:bg-emerald-700 text-white font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 text-center shadow-sm"
              >
                <span>S'inscrire à une formation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => openAmbassadorModal()}
                className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 text-center"
              >
                <span>Devenir ambassadeur</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Bar with Cameroon Flag Accent */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} IMPORTPRO CAMEROUN. Tous droits réservés.
          </div>
          <div className="flex items-center gap-4">
            <span>Douala · Yaoundé · Ngaoundéré · Maroua · Bertoua</span>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-[#007A3D]" />
              <span className="w-2.5 h-2.5 rounded-full bg-[#CE1126]" />
              <span className="w-2.5 h-2.5 rounded-full bg-[#FCD116]" />
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
};
