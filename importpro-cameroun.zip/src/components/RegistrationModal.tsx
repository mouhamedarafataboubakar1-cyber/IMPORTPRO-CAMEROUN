import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { X, MapPin, Calendar, Building2, UserCheck, ShieldCheck, Check } from 'lucide-react';

export const RegistrationModal: React.FC = () => {
  const {
    isRegistrationModalOpen,
    closeRegistrationModal,
    cities,
    ambassadors,
    selectedCityForRegistration,
    defaultReferralCode,
    registerParticipant
  } = useApp();

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [cityId, setCityId] = useState(selectedCityForRegistration || 'ngaoundere');
  const [referralCode, setReferralCode] = useState(defaultReferralCode || '');
  const [paymentMethod, setPaymentMethod] = useState<'Orange Money' | 'MTN Mobile Money' | 'Espèces au bureau'>('Orange Money');
  const [notes, setNotes] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    if (selectedCityForRegistration) {
      setCityId(selectedCityForRegistration);
    }
    if (defaultReferralCode) {
      setReferralCode(defaultReferralCode);
    }
  }, [selectedCityForRegistration, defaultReferralCode, isRegistrationModalOpen]);

  if (!isRegistrationModalOpen) return null;

  const currentCity = cities.find((c) => c.id === cityId) || cities[0];

  // Matched ambassador preview
  const matchedAmbassador = referralCode.trim()
    ? ambassadors.find((a) => a.referralCode.toUpperCase() === referralCode.trim().toUpperCase())
    : currentCity.ambassadorId
    ? ambassadors.find((a) => a.id === currentCity.ambassadorId)
    : undefined;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = registerParticipant({
      fullName,
      phone,
      email,
      cityId,
      referralCode: referralCode.trim() ? referralCode.trim() : undefined,
      paymentMethod,
      notes
    });

    if (result.success) {
      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        closeRegistrationModal();
        setFullName('');
        setPhone('');
        setEmail('');
      }, 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 my-8 relative">
        
        {/* Close Button */}
        <button
          onClick={closeRegistrationModal}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 p-1"
          aria-label="Fermer"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-14 h-14 bg-emerald-100 text-[#007A3D] rounded-full flex items-center justify-center mx-auto">
              <Check className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-extrabold text-slate-900">
              Inscription Pré-enregistrée !
            </h3>
            <p className="text-xs text-slate-600 max-w-xs mx-auto">
              Votre dossier a été transmis au bureau ImportPro de <strong>{currentCity.name}</strong>. Présentez-vous sur place ou confirmez votre règlement au <strong>{currentCity.ambassadorPhone}</strong>.
            </p>
          </div>
        ) : (
          <>
            <div className="mb-5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-[#007A3D] mb-1">
                Formation Physique & Pratique en Présentiel
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                S'inscrire à la Session de Formation
              </h2>
              <p className="text-xs text-slate-600 mt-1">
                Tarif : <strong>35 000 FCFA</strong> · Donnée en personne par le fondateur.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* City Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Sélectionnez votre ville de formation * :
                </label>
                <select
                  value={cityId}
                  onChange={(e) => setCityId(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                >
                  {cities.map((city) => (
                    <option key={city.id} value={city.id}>
                      {city.name} ({city.region}) — {city.nextSessionDate}
                    </option>
                  ))}
                </select>
              </div>

              {/* Dynamic City Info Card */}
              <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100 text-[11px] text-slate-700 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-[#007A3D]">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Session : {currentCity.nextSessionDate} ({currentCity.nextSessionTime})</span>
                </div>
                <div className="flex items-start gap-1.5 text-slate-600">
                  <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                  <span>Bureau local : {currentCity.officeAddress || 'À renseigner'}</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-600">
                  <UserCheck className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>Ambassadeur : {currentCity.ambassadorName || 'À renseigner'}{currentCity.ambassadorPhone && currentCity.ambassadorPhone !== 'À renseigner' ? ` (${currentCity.ambassadorPhone})` : ''}</span>
                </div>
              </div>

              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nom et prénom complet * :
                </label>
                <input
                  type="text"
                  required
                  placeholder="Votre nom et prénom"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                />
              </div>

              {/* Phone & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Téléphone (WhatsApp) * :
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+237 6XX XX XX XX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Adresse Email :
                  </label>
                  <input
                    type="email"
                    placeholder="adresse.email@domaine.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#007A3D]"
                  />
                </div>
              </div>

              {/* Referral Code (optional) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Code de parrainage ambassadeur (facultatif) :
                </label>
                <input
                  type="text"
                  placeholder="Ex : IMP-NGAOUNDERE-01"
                  value={referralCode}
                  onChange={(e) => setReferralCode(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono font-bold text-slate-900 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#007A3D] uppercase"
                />
                {matchedAmbassador && (
                  <div className="text-[11px] text-[#007A3D] font-semibold mt-1 flex items-center gap-1">
                    <span>✓ Parrainé par l'ambassadeur officiel :</span>
                    <strong>{matchedAmbassador.name} ({matchedAmbassador.cityName})</strong>
                  </div>
                )}
              </div>

              {/* Payment Method */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Mode de règlement prévu :
                </label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Orange Money')}
                    className={`py-2 px-2 rounded-lg border text-center font-semibold transition-colors ${
                      paymentMethod === 'Orange Money'
                        ? 'border-orange-500 bg-orange-50 text-orange-950 font-bold'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Orange Money
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('MTN Mobile Money')}
                    className={`py-2 px-2 rounded-lg border text-center font-semibold transition-colors ${
                      paymentMethod === 'MTN Mobile Money'
                        ? 'border-yellow-500 bg-yellow-50 text-yellow-950 font-bold'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    MTN MoMo
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('Espèces au bureau')}
                    className={`py-2 px-2 rounded-lg border text-center font-semibold transition-colors ${
                      paymentMethod === 'Espèces au bureau'
                        ? 'border-emerald-500 bg-emerald-50 text-[#007A3D] font-bold'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Au Bureau
                  </button>
                </div>
              </div>

              <div className="text-[11px] text-slate-500 pt-1">
                Aucun débit bancaire immédiat. L'enregistrement bloque votre place sur les <strong>{currentCity.availableSeats} places restantes</strong>.
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={closeRegistrationModal}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#007A3D] hover:bg-emerald-800 text-white text-xs font-bold rounded-lg shadow-sm transition-colors"
                >
                  Valider ma pré-inscription
                </button>
              </div>

            </form>
          </>
        )}

      </div>
    </div>
  );
};
