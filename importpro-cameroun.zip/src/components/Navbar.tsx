import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Menu,
  X,
  UserCheck,
  Shield,
  ChevronDown,
  Sparkles
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    currentSection,
    setCurrentSection,
    userRole,
    setUserRole,
    currentAmbassador,
    ambassadors,
    setCurrentAmbassadorId,
    openRegistrationModal,
    openLoginModal
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const navLinks = [
    { id: 'accueil', label: 'Accueil' },
    { id: 'formation', label: 'Formation' },
    { id: 'villes', label: 'Villes' },
    { id: 'ambassadeurs', label: 'Ambassadeurs' },
    { id: 'produits', label: 'Produits' }
  ];

  const handleNavClick = (id: string) => {
    setCurrentSection(id);
    setMobileMenuOpen(false);
    // Allow state update to mount section if previously on dashboard
    setTimeout(() => {
      const elem = document.getElementById(id);
      if (elem) {
        elem.scrollIntoView({ behavior: 'smooth' });
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }, 50);
  };

  return (
    <>
      {/* Top Cameroon Flag Accent Line */}
      <div className="h-1.5 w-full flex">
        <div className="h-full flex-1 bg-[#007A3D]" />
        <div className="h-full flex-1 bg-[#CE1126] flex items-center justify-center">
          <span className="text-[7px] text-[#FCD116] leading-none select-none">★</span>
        </div>
        <div className="h-full flex-1 bg-[#FCD116]" />
      </div>

      {/* Main Navigation Bar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          
          {/* Zone 1: Wordmark & Slogan */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick('accueil')}
              className="text-left group flex items-center gap-2.5"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-display font-extrabold text-lg shadow-sm group-hover:bg-[#007A3D] transition-colors shrink-0">
                IP
              </div>
              <div className="flex flex-col">
                <span className="font-display font-black text-lg sm:text-xl tracking-tight text-slate-900 leading-none">
                  IMPORTPRO <span className="text-[#CE1126]">CAMEROUN</span>
                </span>
                <span className="text-[11px] sm:text-xs font-bold text-[#007A3D] tracking-tight mt-0.5">
                  « Apprendre. Importer. Revendre. »
                </span>
              </div>
            </button>
          </div>

          {/* Zone 2: Clean 5 Navigation Links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
            {navLinks.map((link) => {
              const isActive = currentSection === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`relative py-1 transition-colors hover:text-slate-900 whitespace-nowrap ${
                    isActive ? 'text-[#007A3D] font-semibold' : 'text-slate-600'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-[#007A3D] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions & Role Quick Switch */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Role indicator / Mode Switcher */}
            <div className="relative">
              <button
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
                title="Changer de rôle pour tester"
              >
                {userRole === 'admin' ? (
                  <>
                    <Shield className="w-3.5 h-3.5 text-[#CE1126]" />
                    <span>Admin Direction</span>
                  </>
                ) : userRole === 'ambassador' ? (
                  <>
                    <UserCheck className="w-3.5 h-3.5 text-[#007A3D]" />
                    <span className="truncate max-w-[120px]">
                      {currentAmbassador ? `${currentAmbassador.cityName} (${currentAmbassador.name.split(' ')[0]})` : 'Ambassadeur'}
                    </span>
                  </>
                ) : (
                  <>
                    <span className="w-2 h-2 rounded-full bg-slate-400" />
                    <span>Mode Visiteur</span>
                  </>
                )}
                <ChevronDown className="w-3 h-3 text-slate-500" />
              </button>

              {roleDropdownOpen && (
                <div
                  className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onMouseLeave={() => setRoleDropdownOpen(false)}
                >
                  <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Simulateur de Rôle
                  </div>

                  <button
                    onClick={() => {
                      setUserRole('visitor');
                      setRoleDropdownOpen(false);
                      if (currentSection.startsWith('dashboard')) setCurrentSection('accueil');
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 ${
                      userRole === 'visitor' ? 'bg-emerald-50 text-[#007A3D] font-semibold' : 'text-slate-700'
                    }`}
                  >
                    <span>Candidat / Visiteur</span>
                    {userRole === 'visitor' && <span className="text-[10px]">Actif</span>}
                  </button>

                  <div className="border-t border-slate-100 my-1" />
                  <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Ambassadeurs par ville
                  </div>

                  {ambassadors.filter((a) => a.status === 'actif').length === 0 ? (
                    <div className="px-3 py-1.5 text-[11px] text-slate-400 italic">
                      À renseigner via Admin
                    </div>
                  ) : (
                    ambassadors
                      .filter((a) => a.status === 'actif')
                      .slice(0, 4)
                      .map((amb) => (
                        <button
                          key={amb.id}
                          onClick={() => {
                            setUserRole('ambassador');
                            setCurrentAmbassadorId(amb.id);
                            setRoleDropdownOpen(false);
                            setCurrentSection('dashboard-ambassadeur');
                          }}
                          className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-slate-50 ${
                            userRole === 'ambassador' && currentAmbassador?.id === amb.id
                              ? 'bg-emerald-50 text-[#007A3D] font-semibold'
                              : 'text-slate-700'
                          }`}
                        >
                          <span className="truncate">{amb.cityName} — {amb.name}</span>
                        </button>
                      ))
                  )}

                  <div className="border-t border-slate-100 my-1" />
                  <button
                    onClick={() => {
                      setUserRole('admin');
                      setRoleDropdownOpen(false);
                      setCurrentSection('dashboard-admin');
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 ${
                      userRole === 'admin' ? 'bg-red-50 text-[#CE1126] font-semibold' : 'text-slate-700'
                    }`}
                  >
                    <span className="flex items-center gap-1.5 font-medium">
                      <Shield className="w-3.5 h-3.5 text-[#CE1126]" />
                      Administration Globale
                    </span>
                    {userRole === 'admin' && <span className="text-[10px]">Actif</span>}
                  </button>
                </div>
              )}
            </div>

            {/* Quick Access to Active Dashboard if logged in */}
            {userRole === 'ambassador' && (
              <button
                onClick={() => setCurrentSection('dashboard-ambassadeur')}
                className={`px-3 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                  currentSection === 'dashboard-ambassadeur'
                    ? 'bg-[#007A3D] text-white border-[#007A3D]'
                    : 'bg-emerald-50 text-[#007A3D] border-emerald-200 hover:bg-emerald-100'
                }`}
              >
                Tableau Ambassadeur
              </button>
            )}

            {userRole === 'admin' && (
              <button
                onClick={() => setCurrentSection('dashboard-admin')}
                className={`px-3 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                  currentSection === 'dashboard-admin'
                    ? 'bg-[#CE1126] text-white border-[#CE1126]'
                    : 'bg-red-50 text-[#CE1126] border-red-200 hover:bg-red-100'
                }`}
              >
                Panel Admin
              </button>
            )}

            {userRole === 'visitor' && (
              <button
                onClick={openLoginModal}
                className="px-3.5 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 transition-colors"
              >
                Connexion
              </button>
            )}

            {/* Primary Action Button */}
            <button
              onClick={() => openRegistrationModal()}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#007A3D] hover:bg-emerald-800 rounded-lg shadow-sm transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <span>S'inscrire à une formation</span>
            </button>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={() => openRegistrationModal()}
              className="px-3 py-1.5 text-xs font-bold text-white bg-[#007A3D] rounded-md"
            >
              S'inscrire
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 hover:text-slate-900 rounded-md focus:outline-none"
              aria-label="Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3">
            <div className="flex flex-col space-y-2">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`text-left py-2 px-3 rounded-lg text-sm font-medium ${
                    currentSection === link.id
                      ? 'bg-emerald-50 text-[#007A3D] font-bold'
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </div>

            <div className="border-t border-slate-100 pt-3">
              <div className="text-xs text-slate-500 mb-2 font-medium">Espace & Rôles :</div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setUserRole('ambassador');
                    setCurrentSection('dashboard-ambassadeur');
                    setMobileMenuOpen(false);
                  }}
                  className="px-3 py-2 text-xs text-left bg-emerald-50 text-[#007A3D] rounded-lg font-medium border border-emerald-100"
                >
                  Espace Ambassadeur
                </button>
                <button
                  onClick={() => {
                    setUserRole('admin');
                    setCurrentSection('dashboard-admin');
                    setMobileMenuOpen(false);
                  }}
                  className="px-3 py-2 text-xs text-left bg-red-50 text-[#CE1126] rounded-lg font-medium border border-red-100"
                >
                  Espace Admin
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Slogan Sub-Bar */}
      <div className="bg-slate-900 text-white text-xs py-2 px-4 text-center font-medium tracking-wide">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-3">
          <span className="text-[#FCD116] font-display font-bold">IMPORTPRO CAMEROUN</span>
          <span className="text-slate-400">·</span>
          <span className="text-white font-semibold">« Apprendre. Importer. Revendre. »</span>
          <span className="hidden sm:inline text-slate-400">·</span>
          <span className="hidden sm:inline text-emerald-300">
            Formations physiques 100% en présentiel par le fondateur
          </span>
        </div>
      </div>
    </>
  );
};
