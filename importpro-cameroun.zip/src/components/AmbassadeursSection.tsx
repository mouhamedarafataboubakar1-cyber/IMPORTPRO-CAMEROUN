import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Users,
  Award,
  DollarSign,
  Share2,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Phone,
  Building2,
  MapPin,
  ExternalLink
} from 'lucide-react';

export const AmbassadeursSection: React.FC = () => {
  const {
    cities,
    ambassadors,
    openAmbassadorModal,
    setCurrentAmbassadorId,
    setUserRole,
    setCurrentSection
  } = useApp();

  const [simulatedReferrals, setSimulatedReferrals] = useState<number>(25);

  const calculateCommission = (count: number) => count * 2000;

  return (
    <section id="ambassadeurs" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="text-xs font-bold uppercase tracking-wider text-[#007A3D] mb-2 flex items-center justify-center gap-1.5">
            <Award className="w-4 h-4 text-[#FCD116]" />
            <span>Réseau Officiel de Partenaires Locaux</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Devenir ambassadeur
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600">
            Rejoignez le réseau officiel IMPORTPRO CAMEROUN et représentez votre ville tout en générant des revenus réguliers.
          </p>
        </div>

        {/* Clear 3-point explanation card */}
        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 mb-10 shadow-2xs">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-[#007A3D] flex items-center justify-center font-extrabold text-sm shrink-0">
                1
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-1">Bureau & Point Officiel</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Chaque ville peut avoir un ambassadeur et un bureau/point officiel pour accueillir les commerçants et candidats.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-[#007A3D] flex items-center justify-center font-extrabold text-sm shrink-0">
                2
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-1">Lien de Parrainage</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  L'ambassadeur possède un lien de parrainage et un code unique pour enregistrer et suivre ses filleuls en temps réel.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-[#007A3D] flex items-center justify-center font-extrabold text-sm shrink-0">
                3
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-1">Rémunération Garantie</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Il reçoit 2 000 FCFA pour chaque personne parrainée dont l'inscription à la formation est validée.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Requested Section: Commission ambassadeur : 2 000 FCFA par personne validée */}
        <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl mb-14 relative overflow-hidden">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 bg-[#FCD116] text-slate-950 font-bold px-3 py-1 rounded-full text-xs uppercase tracking-wider">
                Rémunération Officielle
              </div>
              
              {/* Exact user requested headline */}
              <div className="space-y-1">
                <div className="text-2xl sm:text-4xl font-extrabold text-[#FCD116] leading-tight">
                  « Commission ambassadeur : 2 000 FCFA par personne validée »
                </div>
              </div>

              <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed max-w-xl">
                Dès qu'une personne s'inscrit avec votre lien de parrainage et que sa participation à la session physique de votre ville est confirmée, votre solde est automatiquement crédité de 2 000 FCFA. Retrait direct par Orange Money ou MTN Mobile Money.
              </p>

              {/* Exact user requested button */}
              <div className="flex flex-wrap items-center gap-4 pt-3">
                <button
                  onClick={() => setCurrentSection('devenir-ambassadeur')}
                  className="px-7 py-3.5 bg-[#FCD116] hover:bg-yellow-400 text-slate-950 font-extrabold text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
                >
                  <span>Devenir ambassadeur</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Interactive Calculator */}
            <div className="lg:col-span-5 bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
              <div className="text-xs font-bold text-white mb-2 flex items-center justify-between">
                <span>Simulateur de vos gains</span>
                <span className="text-[#FCD116] font-bold">2 000 FCFA / inscrit</span>
              </div>

              <div className="my-4">
                <div className="flex justify-between text-xs text-emerald-200 mb-1">
                  <span>Personnes parrainées validées :</span>
                  <span className="font-extrabold text-white text-sm">{simulatedReferrals} personnes</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="100"
                  step="5"
                  value={simulatedReferrals}
                  onChange={(e) => setSimulatedReferrals(Number(e.target.value))}
                  className="w-full accent-[#FCD116] cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-emerald-300 mt-1">
                  <span>5 personnes</span>
                  <span>50 personnes</span>
                  <span>100 personnes</span>
                </div>
              </div>

              <div className="bg-white/15 rounded-xl p-4 text-center border border-white/20">
                <div className="text-[11px] text-emerald-200 uppercase font-semibold">
                  Vos commissions disponibles
                </div>
                <div className="text-2xl sm:text-3xl font-extrabold text-[#FCD116] mt-1 tabular-nums">
                  {(calculateCommission(simulatedReferrals) ?? 0).toLocaleString()} FCFA
                </div>
                <div className="text-[10px] text-white/80 mt-1">
                  Paiement versé sur Orange Money ou MTN Mobile Money
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Ambassador Role Specifications Grid */}
        <div className="mb-14">
          <h3 className="text-xl font-bold text-slate-900 mb-6">
            Ce que possède chaque ambassadeur officiel ImportPro :
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-[#007A3D] flex items-center justify-center font-bold text-sm mb-3">
                01
              </div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">Compte & Bureau Local</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Un compte personnel dédié et une adresse physique officielle (bureau ou point relais) référencée sur le site.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-[#007A3D] flex items-center justify-center font-bold text-sm mb-3">
                02
              </div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">Code & Lien Unique</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Un code de parrainage exclusif (ex: IMP-MAROUA-02) pour suivre automatiquement chaque participant affilié.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-[#007A3D] flex items-center justify-center font-bold text-sm mb-3">
                03
              </div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">Tableau de Bord Live</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Visualisation en temps réel des personnes parrainées, inscriptions validées, commissions et solde disponible.
              </p>
            </div>

            <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-[#007A3D] flex items-center justify-center font-bold text-sm mb-3">
                04
              </div>
              <h4 className="font-bold text-slate-900 text-sm mb-1">Retrait Mobile Money</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Demande de retrait en un clic vers Orange Money ou MTN Mobile Money dès 2 000 FCFA de solde.
              </p>
            </div>
          </div>
        </div>

        {/* Existing Ambassadors by City */}
        <div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-3">
            <div>
              <h3 className="text-xl font-bold text-slate-900">
                Réseau des Ambassadeurs dans les 7 Villes Officielles
              </h3>
              <p className="text-xs sm:text-sm text-slate-600">
                Chaque ville accueille un ambassadeur officiel. Les coordonnées sont validées exclusivement par la direction générale.
              </p>
            </div>
            <button
              onClick={() => setCurrentSection('devenir-ambassadeur')}
              className="text-xs font-bold text-[#007A3D] hover:underline cursor-pointer self-start sm:self-auto"
            >
              Postuler comme ambassadeur →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {cities.map((city) => {
              const assignedAmbassador = ambassadors.find(
                (a) => (a.cityId === city.id || a.id === city.ambassadorId) && a.status === 'actif'
              );

              const hasAmbassador = Boolean(assignedAmbassador) || (city.ambassadorName && city.ambassadorName !== 'À renseigner');
              const ambName = assignedAmbassador ? assignedAmbassador.name : city.ambassadorName;
              const ambOffice = assignedAmbassador ? assignedAmbassador.officeAddress : city.officeAddress;
              const ambPhone = assignedAmbassador ? assignedAmbassador.phone : city.ambassadorPhone;
              const refCode = assignedAmbassador ? assignedAmbassador.referralCode : `IMPORTPRO-${city.code}-001`;

              return (
                <div
                  key={city.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px] font-bold text-[#007A3D] bg-emerald-50 px-2 py-0.5 rounded">
                        {city.name}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        {hasAmbassador ? refCode : 'À renseigner'}
                      </span>
                    </div>

                    <div className="mb-2">
                      <div className="text-[11px] text-slate-400">Ambassadeur officiel :</div>
                      <div className={`font-bold text-base ${hasAmbassador ? 'text-slate-900' : 'text-slate-500 italic'}`}>
                        {ambName || 'À renseigner'}
                      </div>
                    </div>

                    <div className="text-xs text-slate-600 space-y-1.5 mb-4">
                      <div className="flex items-start gap-1.5">
                        <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span className={`line-clamp-2 ${ambOffice === 'À renseigner' ? 'italic text-slate-400' : ''}`}>
                          {ambOffice || 'À renseigner'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className={ambPhone === 'À renseigner' ? 'italic text-slate-400' : ''}>
                          {ambPhone || 'À renseigner'}
                        </span>
                      </div>
                    </div>

                    {assignedAmbassador && (
                      <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1 text-xs">
                        <div className="flex justify-between text-slate-600">
                          <span>Inscrits validés :</span>
                          <strong className="text-slate-900">{assignedAmbassador.validatedCount ?? 0}</strong>
                        </div>
                        <div className="flex justify-between text-slate-600">
                          <span>Commissions :</span>
                          <strong className="text-[#007A3D] font-bold">
                            {(assignedAmbassador.totalCommissions ?? (assignedAmbassador as any).commissionEarned ?? ((assignedAmbassador.validatedCount ?? 0) * 2000)).toLocaleString()} FCFA
                          </strong>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between">
                    {assignedAmbassador ? (
                      <button
                        onClick={() => {
                          setCurrentAmbassadorId(assignedAmbassador.id);
                          setUserRole('ambassador');
                          setCurrentSection('dashboard-ambassadeur');
                        }}
                        className="w-full text-center py-2 px-3 bg-emerald-50 hover:bg-emerald-100 text-[#007A3D] text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>Espace Ambassadeur</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    ) : (
                      <button
                        onClick={() => setCurrentSection('devenir-ambassadeur')}
                        className="w-full text-center py-2 px-3 bg-slate-100 hover:bg-emerald-50 hover:text-[#007A3D] text-slate-700 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>Postuler pour cette ville</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
