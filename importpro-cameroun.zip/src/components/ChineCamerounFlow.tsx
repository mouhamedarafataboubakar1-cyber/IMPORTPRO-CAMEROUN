import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowRight, Search, Ship, DollarSign, CheckCircle2, TrendingUp, ShieldAlert } from 'lucide-react';

export const ChineCamerounFlow: React.FC = () => {
  const { openRegistrationModal } = useApp();

  return (
    <section id="concept" className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with Notre concept */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-[#007A3D] mb-2 flex items-center justify-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#007A3D]" />
            <span>Processus Commercial Maîtrisé</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Notre concept
          </h2>
          
          {/* Requested 4-step Banner */}
          <div className="mt-5 inline-flex flex-wrap items-center justify-center gap-2 sm:gap-3 bg-white border-2 border-slate-200 px-4 sm:px-6 py-3 rounded-2xl shadow-sm">
            <span className="font-extrabold text-sm sm:text-base text-slate-900 flex items-center gap-1.5">
              <span>🇨🇳</span> Chine
            </span>
            <span className="text-[#CE1126] font-bold text-base sm:text-lg">→</span>
            <span className="font-extrabold text-sm sm:text-base text-slate-900 flex items-center gap-1.5">
              <span>📦</span> Importation
            </span>
            <span className="text-[#007A3D] font-bold text-base sm:text-lg">→</span>
            <span className="font-extrabold text-sm sm:text-base text-slate-900 flex items-center gap-1.5">
              <span>🇨🇲</span> Cameroun
            </span>
            <span className="text-[#FCD116] font-bold text-base sm:text-lg">→</span>
            <span className="font-extrabold text-sm sm:text-base text-[#007A3D] flex items-center gap-1.5">
              <span>🛍️</span> Revente
            </span>
          </div>

          <p className="mt-4 text-sm text-slate-600 max-w-2xl mx-auto">
            Une chaîne logistique et commerciale claire, concrète et éprouvée pour vous permettre d'acheter au prix d'usine et de bâtir un commerce florissant au Cameroun.
          </p>
        </div>

        {/* 4 Step Interactive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          
          {/* Step 1: 🇨🇳 Chine */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm relative flex flex-col justify-between hover:border-slate-300 transition-colors">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold font-mono text-slate-400">01</span>
                <span className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold text-base border border-amber-200">
                  🇨🇳
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">
                1. Chine & Sourcing
              </h3>
              <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                Recherche de fabricants fiables et commande directe sans intermédiaires.
              </p>
              <ul className="space-y-2 text-xs text-slate-700 mb-4">
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Maîtrise de 1688, Taobao & Alibaba</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Négociation des prix d'usine réels</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Paiement sécurisé en RMB ou FCFA</span>
                </li>
              </ul>
            </div>
            <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500 font-medium">
              Prix d'achat direct à la source
            </div>
          </div>

          {/* Step 2: 📦 Importation */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm relative flex flex-col justify-between hover:border-slate-300 transition-colors">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold font-mono text-slate-400">02</span>
                <span className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-base border border-blue-200">
                  📦
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">
                2. Importation & Fret
              </h3>
              <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                Expédition sécurisée par voie maritime ou aérienne avec des transitaires fiables.
              </p>
              <ul className="space-y-2 text-xs text-slate-700 mb-4">
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Groupage maritime au CBM (m³)</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Fret aérien express (7-12 jours)</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Carnet de transitaires partenaires</span>
                </li>
              </ul>
            </div>
            <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500 font-medium">
              Suivi et sécurité des colis
            </div>
          </div>

          {/* Step 3: 🇨🇲 Cameroun */}
          <div className="bg-white rounded-2xl p-6 border-2 border-[#007A3D]/40 shadow-sm relative flex flex-col justify-between hover:border-[#007A3D] transition-colors">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold font-mono text-[#007A3D]">03</span>
                <span className="w-9 h-9 rounded-xl bg-emerald-50 text-[#007A3D] flex items-center justify-center font-bold text-base border border-emerald-200">
                  🇨🇲
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">
                3. Cameroun & Réception
              </h3>
              <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                Dédouanement à Douala/Kribi et acheminement vers les 7 villes.
              </p>
              <ul className="space-y-2 text-xs text-slate-700 mb-4">
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Dédouanement complet pris en charge</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Acheminement vers votre ville</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Réception au bureau local</span>
                </li>
              </ul>
            </div>
            <div className="pt-3 border-t border-slate-100 text-[11px] text-[#007A3D] font-bold">
              Disponible dans les 7 villes
            </div>
          </div>

          {/* Step 4: 🛍️ Revente */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm relative flex flex-col justify-between hover:border-slate-300 transition-colors">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold font-mono text-slate-400">04</span>
                <span className="w-9 h-9 rounded-xl bg-red-50 text-[#CE1126] flex items-center justify-center font-bold text-base border border-red-200">
                  🛍️
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mb-2">
                4. Revente & Marge
              </h3>
              <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                Écoulement rapide de vos produits avec de fortes marges bénéficiaires.
              </p>
              <ul className="space-y-2 text-xs text-slate-700 mb-4">
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Marketing WhatsApp Business</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Ventes TikTok & Facebook Ads</span>
                </li>
                <li className="flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#007A3D] shrink-0 mt-0.5" />
                  <span>Marges nettes de +150% à +300%</span>
                </li>
              </ul>
            </div>
            <div className="pt-3 border-t border-slate-100 text-[11px] text-[#CE1126] font-bold">
              Encaissement Orange / MTN MoMo
            </div>
          </div>

        </div>

        {/* Call to action strip */}
        <div className="mt-12 bg-white rounded-2xl p-6 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-[#007A3D] flex items-center justify-center shrink-0">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold text-slate-900 text-sm sm:text-base">
                Prêt à lancer vos premières importations sans risquer votre capital ?
              </div>
              <div className="text-xs text-slate-600">
                Participez à la prochaine session physique animée par le fondateur dans votre ville.
              </div>
            </div>
          </div>
          <button
            onClick={() => openRegistrationModal()}
            className="px-5 py-2.5 bg-[#007A3D] hover:bg-emerald-800 text-white text-xs font-bold rounded-lg transition-colors whitespace-nowrap shadow-sm"
          >
            Réserver ma place en formation
          </button>
        </div>

      </div>
    </section>
  );
};
