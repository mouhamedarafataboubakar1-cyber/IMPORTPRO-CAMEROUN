import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  City,
  Ambassador,
  Registration,
  WithdrawalRequest,
  ProductOpportunity,
  UserRole,
  CeoInfo
} from '../types';
import {
  INITIAL_CITIES,
  INITIAL_AMBASSADORS,
  INITIAL_REGISTRATIONS,
  INITIAL_WITHDRAWALS,
  INITIAL_PRODUCTS,
  INITIAL_CEO_INFO
} from '../data/initialData';

interface Toast {
  id: string;
  type: 'success' | 'info' | 'warning';
  title: string;
  message: string;
}

interface AppContextType {
  // Navigation & View
  currentSection: string;
  setCurrentSection: (section: string) => void;

  // Active Role & Session
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  currentAmbassadorId: string;
  setCurrentAmbassadorId: (id: string) => void;
  currentAmbassador: Ambassador | undefined;

  // CEO / Fondateur Info (Strictly Mouhamed Arafat Aboubakar, other fields « À renseigner », editable only by admin)
  ceoInfo: CeoInfo;
  updateCeoInfo: (updates: Partial<CeoInfo>) => void;

  // Core Data
  cities: City[];
  ambassadors: Ambassador[];
  registrations: Registration[];
  withdrawals: WithdrawalRequest[];
  products: ProductOpportunity[];

  // Modals
  isRegistrationModalOpen: boolean;
  openRegistrationModal: (preselectedCityId?: string, referralCode?: string) => void;
  closeRegistrationModal: () => void;
  selectedCityForRegistration: string;
  defaultReferralCode: string;

  isAmbassadorModalOpen: boolean;
  openAmbassadorModal: () => void;
  closeAmbassadorModal: () => void;

  isLoginModalOpen: boolean;
  openLoginModal: () => void;
  closeLoginModal: () => void;

  // Business Actions
  registerParticipant: (data: {
    fullName: string;
    phone: string;
    email: string;
    cityId: string;
    referralCode?: string;
    paymentMethod: 'Orange Money' | 'MTN Mobile Money' | 'Espèces au bureau';
    notes?: string;
  }) => { success: boolean; message: string; registrationId?: string };

  validateRegistration: (registrationId: string) => void;
  cancelRegistration: (registrationId: string) => void;

  requestWithdrawal: (data: {
    ambassadorId: string;
    amount: number;
    paymentMethod: 'Orange Money' | 'MTN Mobile Money';
    phone: string;
    accountHolderName: string;
  }) => { success: boolean; message: string };

  processWithdrawal: (withdrawalId: string, status: 'validee' | 'rejetee', notes?: string) => void;

  applyForAmbassador: (data: {
    name: string;
    phone: string;
    whatsapp: string;
    email: string;
    cityId: string;
    neighborhood: string;
    officeAddress: string;
    photoUrl?: string;
    password?: string;
  }) => { success: boolean; message: string; ambassadorId?: string };

  // Admin exclusive ambassador actions
  addAmbassador: (data: {
    name: string;
    phone: string;
    whatsapp?: string;
    email?: string;
    cityId: string;
    neighborhood?: string;
    officeAddress?: string;
    referralCode?: string;
    password?: string;
  }) => { success: boolean; message: string; ambassadorId: string };

  approveAmbassador: (ambassadorId: string) => void;
  rejectAmbassador: (ambassadorId: string, reason?: string) => void;
  updateAmbassador: (ambassadorId: string, updates: Partial<Ambassador>) => void;
  assignAmbassadorToCity: (cityId: string, ambassadorId: string) => void;
  removeAmbassadorFromCity: (cityId: string) => void;

  updateCity: (cityId: string, updates: Partial<City>) => void;

  // Feedback Toasts
  toasts: Toast[];
  dismissToast: (id: string) => void;
  showToast: (title: string, message: string, type?: 'success' | 'info' | 'warning') => void;

  // Reset to initial
  resetDemoData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CITIES: 'importpro_cities_v2',
  AMBASSADORS: 'importpro_ambassadors_v2',
  REGISTRATIONS: 'importpro_registrations_v2',
  WITHDRAWALS: 'importpro_withdrawals_v2',
  ROLE: 'importpro_user_role_v2',
  CURRENT_AMB: 'importpro_current_amb_v2',
  CEO: 'importpro_ceo_info_v2',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Purge any old v1 data on mount to eliminate any fictional example coordinates
  useEffect(() => {
    try {
      localStorage.removeItem('importpro_cities_v1');
      localStorage.removeItem('importpro_ambassadors_v1');
      localStorage.removeItem('importpro_registrations_v1');
      localStorage.removeItem('importpro_withdrawals_v1');
      localStorage.removeItem('importpro_user_role_v1');
      localStorage.removeItem('importpro_current_amb_v1');
    } catch {
      // ignore
    }
  }, []);

  const [currentSection, setCurrentSection] = useState<string>('accueil');
  const [userRole, setUserRole] = useState<UserRole>(() => {
    return (localStorage.getItem(STORAGE_KEYS.ROLE) as UserRole) || 'visitor';
  });
  const [currentAmbassadorId, setCurrentAmbassadorId] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.CURRENT_AMB) || '';
  });

  // CEO / Founder info state
  const [ceoInfo, setCeoInfo] = useState<CeoInfo>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CEO);
    if (!saved) return INITIAL_CEO_INFO;
    try {
      const parsed = JSON.parse(saved);
      return {
        ...INITIAL_CEO_INFO,
        ...parsed,
        // Enforce official name Mouhamed Arafat Aboubakar
        name: 'Mouhamed Arafat Aboubakar',
        title: 'PDG / Fondateur'
      };
    } catch {
      return INITIAL_CEO_INFO;
    }
  });

  // Data states
  const [cities, setCities] = useState<City[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CITIES);
    return saved ? JSON.parse(saved) : INITIAL_CITIES;
  });

  const [ambassadors, setAmbassadors] = useState<Ambassador[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.AMBASSADORS);
    if (!saved) return INITIAL_AMBASSADORS;
    try {
      const parsed = JSON.parse(saved);
      if (!Array.isArray(parsed)) return INITIAL_AMBASSADORS;
      return parsed.map((a: any) => ({
        ...a,
        referredCount: typeof a.referredCount === 'number' ? a.referredCount : 0,
        validatedCount: typeof a.validatedCount === 'number' ? a.validatedCount : 0,
        pendingCommissions: typeof a.pendingCommissions === 'number' ? a.pendingCommissions : 0,
        balanceAvailable: typeof a.balanceAvailable === 'number' ? a.balanceAvailable : (typeof a.balance === 'number' ? a.balance : 0),
        totalCommissions: typeof a.totalCommissions === 'number' ? a.totalCommissions : (typeof a.commissionEarned === 'number' ? a.commissionEarned : ((a.validatedCount ?? 0) * 2000)),
      }));
    } catch {
      return INITIAL_AMBASSADORS;
    }
  });

  const [registrations, setRegistrations] = useState<Registration[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REGISTRATIONS);
    if (!saved) return INITIAL_REGISTRATIONS;
    try {
      const parsed = JSON.parse(saved);
      if (!Array.isArray(parsed)) return INITIAL_REGISTRATIONS;
      return parsed.map((r: any) => ({
        ...r,
        amount: typeof r.amount === 'number' ? r.amount : 35000,
        commissionAmount: typeof r.commissionAmount === 'number' ? r.commissionAmount : 2000,
      }));
    } catch {
      return INITIAL_REGISTRATIONS;
    }
  });

  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.WITHDRAWALS);
    if (!saved) return INITIAL_WITHDRAWALS;
    try {
      const parsed = JSON.parse(saved);
      if (!Array.isArray(parsed)) return INITIAL_WITHDRAWALS;
      return parsed.map((w: any) => ({
        ...w,
        amount: typeof w.amount === 'number' ? w.amount : 0,
      }));
    } catch {
      return INITIAL_WITHDRAWALS;
    }
  });

  const [products] = useState<ProductOpportunity[]>(INITIAL_PRODUCTS);

  // Modals state
  const [isRegistrationModalOpen, setIsRegistrationModalOpen] = useState<boolean>(false);
  const [selectedCityForRegistration, setSelectedCityForRegistration] = useState<string>('ngaoundere');
  const [defaultReferralCode, setDefaultReferralCode] = useState<string>('');

  const [isAmbassadorModalOpen, setIsAmbassadorModalOpen] = useState<boolean>(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);

  // Active Ambassador derivation
  const currentAmbassador = ambassadors.find((a) => a.id === currentAmbassadorId) || ambassadors[0];

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CITIES, JSON.stringify(cities));
  }, [cities]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AMBASSADORS, JSON.stringify(ambassadors));
  }, [ambassadors]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REGISTRATIONS, JSON.stringify(registrations));
  }, [registrations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.WITHDRAWALS, JSON.stringify(withdrawals));
  }, [withdrawals]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROLE, userRole);
  }, [userRole]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CURRENT_AMB, currentAmbassadorId);
  }, [currentAmbassadorId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CEO, JSON.stringify(ceoInfo));
  }, [ceoInfo]);

  const showToast = (title: string, message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const openRegistrationModal = (preselectedCityId?: string, referralCode?: string) => {
    if (preselectedCityId) {
      setSelectedCityForRegistration(preselectedCityId);
    }
    if (referralCode) {
      setDefaultReferralCode(referralCode);
      const amb = ambassadors.find(
        (a) => a.referralCode.toUpperCase() === referralCode.trim().toUpperCase()
      );
      if (amb && !preselectedCityId) {
        setSelectedCityForRegistration(amb.cityId);
      }
    } else {
      setDefaultReferralCode('');
    }
    setIsRegistrationModalOpen(true);
  };

  const closeRegistrationModal = () => {
    setIsRegistrationModalOpen(false);
  };

  const openAmbassadorModal = () => setIsAmbassadorModalOpen(true);
  const closeAmbassadorModal = () => setIsAmbassadorModalOpen(false);

  const openLoginModal = () => setIsLoginModalOpen(true);
  const closeLoginModal = () => setIsLoginModalOpen(false);

  // Update CEO / Fondateur info (Admin only)
  const updateCeoInfo = (updates: Partial<CeoInfo>) => {
    setCeoInfo((prev) => ({
      ...prev,
      ...updates,
      // Name and title cannot be altered to keep Mouhamed Arafat Aboubakar
      name: 'Mouhamed Arafat Aboubakar',
      title: 'PDG / Fondateur'
    }));
    showToast('Coordonnées du PDG actualisées', 'Les coordonnées officielles du Fondateur ont été enregistrées avec succès.');
  };

  // Business Action: Register participant for physical session
  const registerParticipant = (data: {
    fullName: string;
    phone: string;
    email: string;
    cityId: string;
    referralCode?: string;
    paymentMethod: 'Orange Money' | 'MTN Mobile Money' | 'Espèces au bureau';
    notes?: string;
  }) => {
    const city = cities.find((c) => c.id === data.cityId) || cities[0];

    // Find ambassador
    let matchedAmbassador: Ambassador | undefined;

    if (data.referralCode && data.referralCode.trim()) {
      const codeClean = data.referralCode.trim().toUpperCase();
      matchedAmbassador = ambassadors.find(
        (a) => a.referralCode.toUpperCase() === codeClean
      );
    }

    if (!matchedAmbassador && city.ambassadorId) {
      matchedAmbassador = ambassadors.find((a) => a.id === city.ambassadorId);
    }

    const newId = `reg-${Date.now().toString().slice(-5)}`;
    const newReg: Registration = {
      id: newId,
      fullName: data.fullName,
      phone: data.phone,
      email: data.email,
      cityId: city.id,
      cityName: city.name,
      referralCode: matchedAmbassador ? matchedAmbassador.referralCode : undefined,
      ambassadorId: matchedAmbassador?.id,
      ambassadorName: matchedAmbassador?.name,
      registeredAt: new Date().toLocaleDateString('fr-FR', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      }),
      status: 'en_attente',
      commissionAmount: 2000,
      commissionStatus: 'en_attente',
      paymentMethod: data.paymentMethod,
      amount: 35000,
      commissionPaid: false,
      notes: data.notes || `Inscription pour la session physique à ${city.name}`
    };

    setRegistrations((prev) => [newReg, ...prev]);

    // Update city seats
    setCities((prev) =>
      prev.map((c) =>
        c.id === city.id
          ? { ...c, availableSeats: Math.max(0, c.availableSeats - 1) }
          : c
      )
    );

    // Update ambassador: increment referredCount and pendingCommissions (2000 FCFA)
    if (matchedAmbassador) {
      setAmbassadors((prev) =>
        prev.map((a) =>
          a.id === matchedAmbassador!.id
            ? {
                ...a,
                referredCount: (a.referredCount ?? 0) + 1,
                pendingCommissions: (a.pendingCommissions ?? 0) + 2000
              }
            : a
        )
      );
    }

    showToast(
      'Inscription enregistrée avec succès !',
      `Votre place pour la formation à ${city.name} a été pré-enregistrée. Confirmation en cours.`
    );

    return { success: true, message: 'Inscription reçue', registrationId: newId };
  };

  // Validate Registration (Admin action -> ONLY NOW commission is credited: +2 000 FCFA to available balance)
  const validateRegistration = (registrationId: string) => {
    const reg = registrations.find((r) => r.id === registrationId);
    if (!reg) return;

    if (reg.status === 'validee') {
      showToast('Déjà validée', "Cette inscription a déjà été validée par l'administration.", 'info');
      return;
    }

    setRegistrations((prev) =>
      prev.map((r) =>
        r.id === registrationId
          ? {
              ...r,
              status: 'validee',
              commissionStatus: 'creditee',
              commissionPaid: true
            }
          : r
      )
    );

    if (reg.ambassadorId) {
      setAmbassadors((prev) =>
        prev.map((a) => {
          if (a.id === reg.ambassadorId) {
            const currentTotal = a.totalCommissions ?? (a as any).commissionEarned ?? ((a.validatedCount ?? 0) * 2000);
            const currentBalance = a.balanceAvailable ?? 0;
            const currentPending = a.pendingCommissions ?? 0;

            return {
              ...a,
              validatedCount: (a.validatedCount ?? 0) + 1,
              pendingCommissions: Math.max(0, currentPending - 2000),
              balanceAvailable: currentBalance + 2000,
              totalCommissions: currentTotal + 2000
            };
          }
          return a;
        })
      );
    }

    showToast(
      'Inscription validée !',
      `L'inscription de ${reg.fullName} pour ${reg.cityName} est confirmée. ${
        reg.ambassadorName ? `Commission de 2 000 FCFA créditée à l'ambassadeur.` : ''
      }`
    );
  };

  // Cancel/reject registration
  const cancelRegistration = (registrationId: string) => {
    const reg = registrations.find((r) => r.id === registrationId);
    if (!reg) return;

    setRegistrations((prev) =>
      prev.map((r) =>
        r.id === registrationId
          ? {
              ...r,
              status: 'annulee',
              commissionStatus: 'annulee'
            }
          : r
      )
    );

    // Free up seat
    setCities((prev) =>
      prev.map((c) =>
        c.id === reg.cityId
          ? { ...c, availableSeats: Math.min(c.totalSeats, c.availableSeats + 1) }
          : c
      )
    );

    // If pending, decrement pending commissions
    if (reg.ambassadorId && reg.status === 'en_attente') {
      setAmbassadors((prev) =>
        prev.map((a) =>
          a.id === reg.ambassadorId
            ? {
                ...a,
                pendingCommissions: Math.max(0, (a.pendingCommissions ?? 0) - 2000)
              }
            : a
        )
      );
    }

    showToast('Inscription annulée', `L'inscription de ${reg.fullName} a été annulée.`, 'info');
  };

  // Request withdrawal (Ambassador action)
  const requestWithdrawal = (data: {
    ambassadorId: string;
    amount: number;
    paymentMethod: 'Orange Money' | 'MTN Mobile Money';
    phone: string;
    accountHolderName: string;
  }) => {
    const ambassador = ambassadors.find((a) => a.id === data.ambassadorId);
    if (!ambassador) {
      showToast('Erreur', 'Ambassadeur non trouvé.', 'warning');
      return { success: false, message: 'Ambassadeur introuvable' };
    }

    if ((ambassador.balanceAvailable ?? 0) < data.amount) {
      showToast(
        'Solde insuffisant',
        `Votre solde disponible (${(ambassador.balanceAvailable ?? 0).toLocaleString()} FCFA) est inférieur au montant demandé (${(data.amount ?? 0).toLocaleString()} FCFA).`,
        'warning'
      );
      return { success: false, message: 'Solde insuffisant' };
    }

    if (data.amount < 2000) {
      showToast('Montant minimum', 'Le montant minimum de retrait est de 2 000 FCFA.', 'warning');
      return { success: false, message: 'Montant minimum non atteint' };
    }

    const newId = `wth-${Date.now().toString().slice(-4)}`;
    const newRequest: WithdrawalRequest = {
      id: newId,
      ambassadorId: ambassador.id,
      ambassadorName: ambassador.name,
      cityName: ambassador.cityName,
      amount: data.amount,
      paymentMethod: data.paymentMethod,
      phone: data.phone,
      accountHolderName: data.accountHolderName,
      status: 'en_attente',
      createdAt: new Date().toLocaleDateString('fr-FR', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      }),
      notes: `Demande de retrait vers ${data.phone} (${data.accountHolderName})`
    };

    // Deduct immediately from available balance to prevent double withdrawal
    setAmbassadors((prev) =>
      prev.map((a) =>
        a.id === ambassador.id
          ? { ...a, balanceAvailable: Math.max(0, (a.balanceAvailable ?? 0) - data.amount) }
          : a
      )
    );

    setWithdrawals((prev) => [newRequest, ...prev]);

    showToast(
      'Demande de retrait transmise !',
      `Votre demande de ${(data.amount ?? 0).toLocaleString()} FCFA via ${data.paymentMethod} a été envoyée. Elle sera validée par la direction sous 24h.`
    );

    return { success: true, message: 'Demande soumise' };
  };

  // Process withdrawal (Admin action: Validé ou Rejeté)
  const processWithdrawal = (withdrawalId: string, status: 'validee' | 'rejetee', notes?: string) => {
    const item = withdrawals.find((w) => w.id === withdrawalId);
    if (!item) return;

    setWithdrawals((prev) =>
      prev.map((w) =>
        w.id === withdrawalId
          ? {
              ...w,
              status,
              notes: notes || w.notes,
              processedAt: new Date().toLocaleDateString('fr-FR', {
                day: '2-digit',
                month: 'long',
                year: 'numeric'
              })
            }
          : w
      )
    );

    if (status === 'rejetee') {
      // Refund balance to ambassador
      setAmbassadors((prev) =>
        prev.map((a) =>
          a.id === item.ambassadorId
            ? { ...a, balanceAvailable: (a.balanceAvailable ?? 0) + (item.amount ?? 0) }
            : a
        )
      );
      showToast('Retrait rejeté', `Le montant de ${(item.amount ?? 0).toLocaleString()} FCFA a été recrédité à l'ambassadeur.`, 'warning');
    } else {
      showToast(
        'Paiement validé !',
        `Le retrait de ${(item.amount ?? 0).toLocaleString()} FCFA vers ${item.phone} (${item.accountHolderName} - ${item.paymentMethod}) a été marqué comme Validé.`
      );
    }
  };

  // Apply to become ambassador (Status is initially 'en_attente' until admin approval)
  const applyForAmbassador = (data: {
    name: string;
    phone: string;
    whatsapp: string;
    email: string;
    cityId: string;
    neighborhood: string;
    officeAddress: string;
    photoUrl?: string;
    password?: string;
  }) => {
    const city = cities.find((c) => c.id === data.cityId) || cities[0];
    const newId = `amb-cand-${Date.now().toString().slice(-4)}`;

    const newAmb: Ambassador = {
      id: newId,
      name: data.name,
      phone: data.phone,
      whatsapp: data.whatsapp || data.phone,
      email: data.email,
      cityId: city.id,
      cityName: city.name,
      neighborhood: data.neighborhood,
      officeAddress: data.officeAddress,
      photoUrl: data.photoUrl,
      password: data.password || 'password123',
      referralCode: 'EN-ATTENTE-VALIDATION',
      status: 'en_attente',
      referredCount: 0,
      validatedCount: 0,
      pendingCommissions: 0,
      balanceAvailable: 0,
      totalCommissions: 0,
      joinedDate: new Date().toLocaleDateString('fr-FR', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      })
    };

    setAmbassadors((prev) => [newAmb, ...prev]);

    showToast(
      'Candidature enregistrée !',
      `Votre candidature pour la ville de ${city.name} (${data.neighborhood}) a été transmise avec le statut « En attente de validation » par l'administrateur.`
    );

    return { success: true, message: 'Candidature enregistrée avec succès', ambassadorId: newId };
  };

  // Admin directly adds an official ambassador
  const addAmbassador = (data: {
    name: string;
    phone: string;
    whatsapp?: string;
    email?: string;
    cityId: string;
    neighborhood?: string;
    officeAddress?: string;
    referralCode?: string;
    password?: string;
  }) => {
    const city = cities.find((c) => c.id === data.cityId) || cities[0];
    const cityCode = city.code || city.name.substring(0, 3).toUpperCase();
    const newId = `amb-${Date.now().toString().slice(-5)}`;

    const existingCount = ambassadors.filter((a) => a.cityId === city.id && a.status === 'actif').length;
    const seq = String(existingCount + 1).padStart(3, '0');
    const officialCode = data.referralCode && data.referralCode.trim() 
      ? data.referralCode.trim().toUpperCase() 
      : `IMPORTPRO-${cityCode}-${seq}`;

    const newAmb: Ambassador = {
      id: newId,
      name: data.name,
      phone: data.phone,
      whatsapp: data.whatsapp || data.phone,
      email: data.email || 'À renseigner',
      cityId: city.id,
      cityName: city.name,
      neighborhood: data.neighborhood || 'À renseigner',
      officeAddress: data.officeAddress || 'À renseigner',
      referralCode: officialCode,
      status: 'actif',
      referredCount: 0,
      validatedCount: 0,
      pendingCommissions: 0,
      balanceAvailable: 0,
      totalCommissions: 0,
      password: data.password || 'ambassadeur123',
      joinedDate: new Date().toLocaleDateString('fr-FR', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      })
    };

    setAmbassadors((prev) => [newAmb, ...prev]);

    // Automatically assign as official ambassador for this city
    setCities((prev) =>
      prev.map((c) =>
        c.id === city.id
          ? {
              ...c,
              ambassadorId: newAmb.id,
              ambassadorName: newAmb.name,
              ambassadorPhone: newAmb.phone,
              neighborhood: newAmb.neighborhood,
              officeAddress: newAmb.officeAddress
            }
          : c
      )
    );

    setCurrentAmbassadorId(newId);

    showToast(
      'Ambassadeur officiel ajouté !',
      `${newAmb.name} a été affecté à la ville de ${city.name} avec le code ${officialCode}.`
    );

    return { success: true, message: 'Ambassadeur officiel ajouté', ambassadorId: newId };
  };

  // Admin approves ambassador application -> generates official unique code (e.g. IMPORTPRO-NGA-001)
  const approveAmbassador = (ambassadorId: string) => {
    const candidate = ambassadors.find((a) => a.id === ambassadorId);
    if (!candidate) return;

    const city = cities.find((c) => c.id === candidate.cityId) || cities[0];
    const cityCode = city.code || city.name.substring(0, 3).toUpperCase();
    
    // Count active ambassadors in this city
    const existingCount = ambassadors.filter((a) => a.cityId === city.id && a.status === 'actif').length;
    const seq = String(existingCount + 1).padStart(3, '0');
    const generatedCode = `IMPORTPRO-${cityCode}-${seq}`;

    setAmbassadors((prev) =>
      prev.map((a) =>
        a.id === ambassadorId
          ? {
              ...a,
              status: 'actif',
              referralCode: generatedCode
            }
          : a
      )
    );

    // Update city official ambassador info
    setCities((prev) =>
      prev.map((c) =>
        c.id === city.id
          ? {
              ...c,
              ambassadorId: candidate.id,
              ambassadorName: candidate.name,
              ambassadorPhone: candidate.phone,
              neighborhood: candidate.neighborhood,
              officeAddress: candidate.officeAddress
            }
          : c
      )
    );

    showToast(
      'Candidature validée !',
      `L'ambassadeur ${candidate.name} à ${city.name} est maintenant actif avec le code officiel ${generatedCode}.`
    );
  };

  // Admin rejects ambassador application
  const rejectAmbassador = (ambassadorId: string, reason?: string) => {
    setAmbassadors((prev) =>
      prev.map((a) => (a.id === ambassadorId ? { ...a, status: 'rejete' } : a))
    );
    showToast('Candidature refusée', `La candidature a été marquée comme rejetée.`);
  };

  // Admin updates ambassador details
  const updateAmbassador = (ambassadorId: string, updates: Partial<Ambassador>) => {
    setAmbassadors((prev) =>
      prev.map((a) => (a.id === ambassadorId ? { ...a, ...updates } : a))
    );

    // If name, phone, or address changed, keep the city in sync if assigned
    const target = ambassadors.find((a) => a.id === ambassadorId);
    if (target) {
      const updatedName = updates.name ?? target.name;
      const updatedPhone = updates.phone ?? target.phone;
      const updatedOffice = updates.officeAddress ?? target.officeAddress;
      const updatedNeighborhood = updates.neighborhood ?? target.neighborhood;

      setCities((prev) =>
        prev.map((c) =>
          c.ambassadorId === ambassadorId
            ? {
                ...c,
                ambassadorName: updatedName,
                ambassadorPhone: updatedPhone,
                officeAddress: updatedOffice,
                neighborhood: updatedNeighborhood
              }
            : c
        )
      );
    }

    showToast('Ambassadeur mis à jour', 'Les informations ont été actualisées avec succès.');
  };

  // Assign an ambassador to a city
  const assignAmbassadorToCity = (cityId: string, ambassadorId: string) => {
    const amb = ambassadors.find((a) => a.id === ambassadorId);
    if (!amb) return;

    setCities((prev) =>
      prev.map((c) =>
        c.id === cityId
          ? {
              ...c,
              ambassadorId: amb.id,
              ambassadorName: amb.name,
              ambassadorPhone: amb.phone,
              neighborhood: amb.neighborhood,
              officeAddress: amb.officeAddress
            }
          : c
      )
    );

    showToast('Ville affectée', `${amb.name} est désormais l'ambassadeur officiel pour cette ville.`);
  };

  // Remove ambassador from a city
  const removeAmbassadorFromCity = (cityId: string) => {
    setCities((prev) =>
      prev.map((c) =>
        c.id === cityId
          ? {
              ...c,
              ambassadorId: '',
              ambassadorName: 'À renseigner',
              ambassadorPhone: 'À renseigner',
              neighborhood: 'À renseigner',
              officeAddress: 'À renseigner'
            }
          : c
      )
    );
    showToast('Ambassadeur retiré', 'La ville affiche désormais « À renseigner » pour son ambassadeur.');
  };

  const updateCity = (cityId: string, updates: Partial<City>) => {
    setCities((prev) =>
      prev.map((c) => (c.id === cityId ? { ...c, ...updates } : c))
    );
    showToast('Ville mise à jour', 'Les informations de la session ont été actualisées.');
  };

  const resetDemoData = () => {
    localStorage.removeItem(STORAGE_KEYS.CITIES);
    localStorage.removeItem(STORAGE_KEYS.AMBASSADORS);
    localStorage.removeItem(STORAGE_KEYS.REGISTRATIONS);
    localStorage.removeItem(STORAGE_KEYS.WITHDRAWALS);
    localStorage.removeItem(STORAGE_KEYS.CEO);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_AMB);
    setCities(INITIAL_CITIES);
    setAmbassadors(INITIAL_AMBASSADORS);
    setRegistrations(INITIAL_REGISTRATIONS);
    setWithdrawals(INITIAL_WITHDRAWALS);
    setCeoInfo(INITIAL_CEO_INFO);
    setUserRole('visitor');
    setCurrentAmbassadorId('');
    showToast('Données réinitialisées', 'Toutes les coordonnées fictives ont été purgées. Les informations sont remises à « À renseigner ».');
  };

  return (
    <AppContext.Provider
      value={{
        currentSection,
        setCurrentSection,
        userRole,
        setUserRole,
        currentAmbassadorId,
        setCurrentAmbassadorId,
        currentAmbassador,
        ceoInfo,
        updateCeoInfo,
        cities,
        ambassadors,
        registrations,
        withdrawals,
        products,
        isRegistrationModalOpen,
        openRegistrationModal,
        closeRegistrationModal,
        selectedCityForRegistration,
        defaultReferralCode,
        isAmbassadorModalOpen,
        openAmbassadorModal,
        closeAmbassadorModal,
        isLoginModalOpen,
        openLoginModal,
        closeLoginModal,
        registerParticipant,
        validateRegistration,
        cancelRegistration,
        requestWithdrawal,
        processWithdrawal,
        applyForAmbassador,
        addAmbassador,
        approveAmbassador,
        rejectAmbassador,
        updateAmbassador,
        assignAmbassadorToCity,
        removeAmbassadorFromCity,
        updateCity,
        toasts,
        dismissToast,
        showToast,
        resetDemoData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
