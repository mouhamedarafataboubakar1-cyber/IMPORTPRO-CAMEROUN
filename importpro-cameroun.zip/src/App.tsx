/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ChineCamerounFlow } from './components/ChineCamerounFlow';
import { FormationSection } from './components/FormationSection';
import { VillesSection } from './components/VillesSection';
import { AmbassadeursSection } from './components/AmbassadeursSection';
import { ProduitsSection } from './components/ProduitsSection';
import { AmbassadorDashboard } from './components/AmbassadorDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { DevenirAmbassadeurPage } from './components/DevenirAmbassadeurPage';
import { RegistrationModal } from './components/RegistrationModal';
import { BecomeAmbassadorModal } from './components/BecomeAmbassadorModal';
import { LoginModal } from './components/LoginModal';
import { ToastContainer } from './components/ToastContainer';
import { Footer } from './components/Footer';

const AppContent: React.FC = () => {
  const { currentSection, openRegistrationModal } = useApp();

  // Check URL query parameters for referral or city pre-selection
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const refCode = params.get('ref');
    const city = params.get('ville');
    if (refCode || city) {
      openRegistrationModal(city || undefined, refCode || undefined);
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#FBFBFA] text-slate-900 selection:bg-emerald-500 selection:text-white">
      <Navbar />

      <main className="flex-1">
        {currentSection === 'dashboard-ambassadeur' ? (
          <AmbassadorDashboard />
        ) : currentSection === 'dashboard-admin' ? (
          <AdminDashboard />
        ) : currentSection === 'devenir-ambassadeur' ? (
          <DevenirAmbassadeurPage />
        ) : (
          <>
            <Hero />
            <ChineCamerounFlow />
            <FormationSection />
            <VillesSection />
            <AmbassadeursSection />
            <ProduitsSection />
          </>
        )}
      </main>

      <Footer />

      {/* Interactive Global Modals & Notifications */}
      <RegistrationModal />
      <BecomeAmbassadorModal />
      <LoginModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
