export interface City {
  id: string;
  name: string;
  code: string; // e.g. 'NGA', 'MAR', 'BER', 'GBL', 'PIT', 'GUI', 'FIG'
  region: string;
  officeAddress: string;
  neighborhood: string;
  nextSessionDate: string;
  nextSessionTime: string;
  venueName: string;
  ambassadorId: string;
  ambassadorName: string;
  ambassadorPhone: string;
  totalSeats: number;
  availableSeats: number;
  status: 'open' | 'filling_fast' | 'upcoming';
  description: string;
}

export interface Ambassador {
  id: string;
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  cityId: string;
  cityName: string;
  neighborhood: string; // Quartier
  officeAddress: string; // Bureau ou point local
  photoUrl?: string;
  password?: string;
  referralCode: string; // e.g. IMPORTPRO-NGA-001
  status: 'actif' | 'en_attente' | 'rejete';
  referredCount: number;
  validatedCount: number;
  pendingCommissions: number; // Inscriptions en attente * 2000 FCFA
  balanceAvailable: number; // Commissions validées disponibles
  totalCommissions: number; // Total cumulé historique
  joinedDate: string;
}

export interface Registration {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  cityId: string;
  cityName: string;
  referralCode?: string;
  ambassadorId?: string;
  ambassadorName?: string;
  registeredAt: string;
  status: 'en_attente' | 'validee' | 'annulee';
  commissionAmount: number; // 2000 FCFA
  commissionStatus: 'en_attente' | 'creditee' | 'annulee';
  paymentMethod: 'Orange Money' | 'MTN Mobile Money' | 'Espèces au bureau';
  amount: number; // e.g. 35000 FCFA
  commissionPaid: boolean;
  notes?: string;
}

export interface WithdrawalRequest {
  id: string;
  ambassadorId: string;
  ambassadorName: string;
  cityName: string;
  amount: number;
  paymentMethod: 'Orange Money' | 'MTN Mobile Money';
  phone: string;
  accountHolderName: string; // Nom du titulaire
  status: 'en_attente' | 'validee' | 'rejetee';
  createdAt: string;
  processedAt?: string;
  notes?: string;
}

export interface ProductOpportunity {
  id: string;
  name: string;
  category: 'High-Tech' | 'Solaire & Énergie' | 'Mode & Bagagerie' | 'Maison & Électro';
  image: string;
  chinaPriceRMB: number;
  chinaPriceFCFA: number;
  transportEstimateFCFA: number;
  costTotalFCFA: number;
  retailPriceCameroonFCFA: number;
  marginFCFA: number;
  marginPercent: number;
  minOrderQuantity: number;
  sourcingPlatform: '1688' | 'Alibaba' | 'Yiwu Direct';
  trendingReason: string;
}

export type UserRole = 'visitor' | 'ambassador' | 'admin';

export interface CeoInfo {
  title: string;
  name: string;
  phone: string;
  whatsapp: string;
  email: string;
  officeAddress: string;
  city: string;
}

export interface UserSession {
  role: UserRole;
  currentAmbassadorId?: string;
  currentUserName?: string;
}

