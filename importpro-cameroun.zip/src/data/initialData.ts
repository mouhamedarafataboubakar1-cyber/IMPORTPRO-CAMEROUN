import { City, Ambassador, Registration, WithdrawalRequest, ProductOpportunity, CeoInfo } from '../types';

export const HERO_IMAGE = '/src/assets/images/hero_import_cameroon_1790547523850.jpg';
export const WORKSHOP_IMAGE = '/src/assets/images/workshop_formation_direct_1790547536937.jpg';
export const PRODUCTS_IMAGE = '/src/assets/images/import_products_showcase_1790547548241.jpg';

export const INITIAL_CEO_INFO: CeoInfo = {
  title: 'PDG / Fondateur',
  name: 'Mouhamed Arafat Aboubakar',
  phone: 'À renseigner',
  whatsapp: 'À renseigner',
  email: 'À renseigner',
  officeAddress: 'À renseigner',
  city: 'À renseigner'
};

export const INITIAL_CITIES: City[] = [
  {
    id: 'ngaoundere',
    name: 'Ngaoundéré',
    code: 'NGA',
    region: 'Adamaoua',
    neighborhood: 'À renseigner',
    officeAddress: 'À renseigner',
    nextSessionDate: '12 Octobre 2026',
    nextSessionTime: '08h30 - 17h00',
    venueName: 'À renseigner',
    ambassadorId: '',
    ambassadorName: 'À renseigner',
    ambassadorPhone: 'À renseigner',
    totalSeats: 35,
    availableSeats: 35,
    status: 'open',
    description: 'Hub commercial du Grand Nord, liaison ferroviaire directe Camrail depuis Douala.'
  },
  {
    id: 'maroua',
    name: 'Maroua',
    code: 'MAR',
    region: 'Extrême-Nord',
    neighborhood: 'À renseigner',
    officeAddress: 'À renseigner',
    nextSessionDate: '19 Octobre 2026',
    nextSessionTime: '08h30 - 17h00',
    venueName: 'À renseigner',
    ambassadorId: '',
    ambassadorName: 'À renseigner',
    ambassadorPhone: 'À renseigner',
    totalSeats: 40,
    availableSeats: 40,
    status: 'open',
    description: 'Grand carrefour de négoce transfrontalier (Nigeria & Tchad), forte demande en quincaillerie et solaire.'
  },
  {
    id: 'bertoua',
    name: 'Bertoua',
    code: 'BER',
    region: 'Est',
    neighborhood: 'À renseigner',
    officeAddress: 'À renseigner',
    nextSessionDate: '26 Octobre 2026',
    nextSessionTime: '08h30 - 17h00',
    venueName: 'À renseigner',
    ambassadorId: '',
    ambassadorName: 'À renseigner',
    ambassadorPhone: 'À renseigner',
    totalSeats: 30,
    availableSeats: 30,
    status: 'open',
    description: 'Porte d\'entrée économique de la région de l\'Est avec un accès direct aux réseaux de distribution.'
  },
  {
    id: 'garoua-boulai',
    name: 'Garoua-Boulaï',
    code: 'GBL',
    region: 'Est / Frontière RCA',
    neighborhood: 'À renseigner',
    officeAddress: 'À renseigner',
    nextSessionDate: '02 Novembre 2026',
    nextSessionTime: '09h00 - 17h00',
    venueName: 'À renseigner',
    ambassadorId: '',
    ambassadorName: 'À renseigner',
    ambassadorPhone: 'À renseigner',
    totalSeats: 25,
    availableSeats: 25,
    status: 'open',
    description: 'Zone frontalière stratégique à très fort pouvoir d\'achat pour les grossistes et revendeurs régionaux.'
  },
  {
    id: 'pitoa',
    name: 'Pitoa',
    code: 'PIT',
    region: 'Nord',
    neighborhood: 'À renseigner',
    officeAddress: 'À renseigner',
    nextSessionDate: '09 Novembre 2026',
    nextSessionTime: '08h30 - 16h30',
    venueName: 'À renseigner',
    ambassadorId: '',
    ambassadorName: 'À renseigner',
    ambassadorPhone: 'À renseigner',
    totalSeats: 25,
    availableSeats: 25,
    status: 'open',
    description: 'Bassin agro-pastoral et commercial dynamique, réceptacle idéal pour le petit matériel motorisé et accessoires.'
  },
  {
    id: 'guider',
    name: 'Guider',
    code: 'GUI',
    region: 'Nord (Mayo-Louti)',
    neighborhood: 'À renseigner',
    officeAddress: 'À renseigner',
    nextSessionDate: '16 Novembre 2026',
    nextSessionTime: '08h30 - 16h30',
    venueName: 'À renseigner',
    ambassadorId: '',
    ambassadorName: 'À renseigner',
    ambassadorPhone: 'À renseigner',
    totalSeats: 25,
    availableSeats: 25,
    status: 'open',
    description: 'Chef-lieu du Mayo-Louti réputé pour sa communauté active de jeunes commerçants en quête d\'indépendance.'
  },
  {
    id: 'figuil',
    name: 'Figuil',
    code: 'FIG',
    region: 'Nord (Bassin Industriel)',
    neighborhood: 'À renseigner',
    officeAddress: 'À renseigner',
    nextSessionDate: '23 Novembre 2026',
    nextSessionTime: '09h00 - 17h00',
    venueName: 'À renseigner',
    ambassadorId: '',
    ambassadorName: 'À renseigner',
    ambassadorPhone: 'À renseigner',
    totalSeats: 25,
    availableSeats: 25,
    status: 'open',
    description: 'Carrefour industriel et commercial situé entre le Nord et l\'Extrême-Nord du Cameroun.'
  }
];

export const INITIAL_AMBASSADORS: Ambassador[] = [];

export const INITIAL_REGISTRATIONS: Registration[] = [];

export const INITIAL_WITHDRAWALS: WithdrawalRequest[] = [];

export const INITIAL_PRODUCTS: ProductOpportunity[] = [
  {
    id: 'prod-01',
    name: 'Montre Connectée AMOLED Ultra Pro',
    category: 'High-Tech',
    image: PRODUCTS_IMAGE,
    chinaPriceRMB: 38,
    chinaPriceFCFA: 3200,
    transportEstimateFCFA: 1100,
    costTotalFCFA: 4300,
    retailPriceCameroonFCFA: 15000,
    marginFCFA: 10700,
    marginPercent: 248,
    minOrderQuantity: 10,
    sourcingPlatform: '1688',
    trendingReason: 'Très forte demande auprès des jeunes et cadres. Excellente marge en vente directe.'
  },
  {
    id: 'prod-02',
    name: 'Écouteurs TWS Sans Fil Réduction de Bruit',
    category: 'High-Tech',
    image: PRODUCTS_IMAGE,
    chinaPriceRMB: 17,
    chinaPriceFCFA: 1450,
    transportEstimateFCFA: 650,
    costTotalFCFA: 2100,
    retailPriceCameroonFCFA: 7500,
    marginFCFA: 5400,
    marginPercent: 257,
    minOrderQuantity: 20,
    sourcingPlatform: '1688',
    trendingReason: 'Produit compact à faible encombrement volumétrique, idéal pour expédition par fret aérien.'
  },
  {
    id: 'prod-03',
    name: 'Projecteur Solaire LED Autonome 200W',
    category: 'Solaire & Énergie',
    image: PRODUCTS_IMAGE,
    chinaPriceRMB: 65,
    chinaPriceFCFA: 5500,
    transportEstimateFCFA: 2800,
    costTotalFCFA: 8300,
    retailPriceCameroonFCFA: 22000,
    marginFCFA: 13700,
    marginPercent: 165,
    minOrderQuantity: 5,
    sourcingPlatform: 'Yiwu Direct',
    trendingReason: 'Crucial dans les zones à délestages fréquents. Revente immédiate aux particuliers et commerces.'
  },
  {
    id: 'prod-04',
    name: 'Sac à Dos Business Antivol avec Port USB',
    category: 'Mode & Bagagerie',
    image: PRODUCTS_IMAGE,
    chinaPriceRMB: 32,
    chinaPriceFCFA: 2700,
    transportEstimateFCFA: 1300,
    costTotalFCFA: 4000,
    retailPriceCameroonFCFA: 12000,
    marginFCFA: 8000,
    marginPercent: 200,
    minOrderQuantity: 15,
    sourcingPlatform: 'Alibaba',
    trendingReason: 'Prisé des étudiants et fonctionnaires. Robuste, imperméable et très valorisant en vitrine.'
  },
  {
    id: 'prod-05',
    name: 'Tondeuse Professionnelle de Précision Rechargeable',
    category: 'Maison & Électro',
    image: PRODUCTS_IMAGE,
    chinaPriceRMB: 24,
    chinaPriceFCFA: 2050,
    transportEstimateFCFA: 850,
    costTotalFCFA: 2900,
    retailPriceCameroonFCFA: 9000,
    marginFCFA: 6100,
    marginPercent: 210,
    minOrderQuantity: 10,
    sourcingPlatform: '1688',
    trendingReason: 'Utilisée par les salons de coiffure locaux et particuliers. Fiabilité démontrée et excellente rotation de stock.'
  },
  {
    id: 'prod-06',
    name: 'Mini Scelleuse Thermique Rechargeable USB',
    category: 'Maison & Électro',
    image: PRODUCTS_IMAGE,
    chinaPriceRMB: 8,
    chinaPriceFCFA: 680,
    transportEstimateFCFA: 350,
    costTotalFCFA: 1030,
    retailPriceCameroonFCFA: 4000,
    marginFCFA: 2970,
    marginPercent: 288,
    minOrderQuantity: 30,
    sourcingPlatform: '1688',
    trendingReason: 'Produit viral, très recherché pour la conservation des aliments et épices dans les ménages.'
  }
];
